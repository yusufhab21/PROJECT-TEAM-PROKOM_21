from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from ttkthemes import ThemedTk
from customtkinter import *
from PIL import Image,ImageTk
from tkcalendar import Calendar
from os import system
import datetime
import random
import string
import json
with open('data.kereta.json', 'r') as file:
    jadwalKereta = json.load(file)
with open("purchase.history.json", 'r') as file:
    history = json.loads(file.read())

def loginAkun():
    global login
    global tgl_banding
    tgl_banding = ""
    login = Tk()
    login.title("K21 Railway Access")
    login.configure(bg="#fff")
    login.geometry("920x500+170+80")
    login.resizable(False, False)

    ##################################

    img = (Image.open("imgsrc\k21logo.png"))
    img_resize = img.resize((600,360), Image.ANTIALIAS)
    new_image2 = ImageTk.PhotoImage(img_resize)
    Label(login, image=new_image2, bg="white").place(x=-40, y=60)

    ##################################

    frame = Frame(login, width=350, height=350, bg="white")
    frame.place(x=520, y=70)

    ##################################

    heading = Label(frame, text="Sign In", bg="white",fg="#57a1f8", font=("Microsoft YaHei UI Light", 20, "bold"))
    heading.place(x=115, y=8)
    
    Button(login, text="Light", width=4, height=1, bg="#fff", fg="#333333" ,command=ganti_login_light, border=1).place(x=870, y=10)

    ##################################

    def cekAkun():
        global Username
        system("cls")
        with open('data.akun.k21.json', 'r') as file:
            data_akun = json.load(file)
        Username = str(user.get())
        Password = str(pw.get())
        for i in range(0, len(data_akun["akun"])):
            if Username == data_akun["akun"][i]["username"] and Password == data_akun["akun"][i]["password"]:    
                login.destroy()
                mainPage()
                break
        else:
            messagebox.showerror("Login Gagal", "Username atau password salah!")

    ################################## 
    
    def isiuser(e):
        user.delete(0, "end")
    def tidakisiuser(e):
        name = user.get()
        if name == "":
            user.insert(0, "Username")
    user = Entry(frame, width=37, fg="Black", border=0, bg="white", font=("Microsoft YaHei UI Light", 11))
    user.place(x=30, y=80)
    user.insert(0, "Username")
    user.bind("<FocusIn>", isiuser)
    user.bind("<FocusOut>", tidakisiuser)
    Frame(frame, width=295, height=2, bg="black").place(x=25, y=107)

    #################################
    
    def isiuser(e):
        pw.delete(0, "end")
        pw.configure(show="*")
    def tidakisiuser(e):
        passw = pw.get()
        pw.configure(show="*")
        if passw == "":
            pw.configure(show="")
            pw.insert(0, "Password")
    pw = Entry(frame, width=37, fg="Black", border=0, bg="white", font=("Microsoft YaHei UI Light", 11))
    pw.place(x=30, y=150)
    pw.insert(0, "Password")
    pw.bind("<FocusIn>", isiuser)
    pw.bind("<FocusOut>", tidakisiuser)
    Frame(frame, width=295, height=2, bg="black").place(x=25, y=177)

    #################################

    CTkButton(frame, width=298, height=30, text="Sign In", text_color="black", fg_color="#57a1f8", border_spacing=0, corner_radius=5, hover_color="#0079ff", command=cekAkun).place(x=24, y=204)
    label_regis = Label(frame, text="Belum punya akun?", fg="black", bg="white", font=("Microsoft YaHei UI Light", 9))
    label_regis.place(x=83, y=250)
    regis_button = Button(frame, width=6, text="Sign Up", border=0, fg="#57a1f8", bg="white", cursor="hand2", command=ganti_regis)
    regis_button.place(x=200, y=250)
    system("cls")
    login.mainloop()


def bikinAkun():
    global regis
    regis = Tk()
    regis.title("K21 Railway Access")
    regis.geometry("920x500+170+80")
    regis.configure(bg="#fff")
    regis.resizable(False, False)

    ####################################
    
    frame = Frame(regis, width=350, height=350, bg="#fff")
    frame.place(x=285, y=40)

    ####################################

    heading = Label(frame, text="Sign Up", bg="white",fg="#57a1f8", font=("Microsoft YaHei UI Light", 20, "bold"))
    heading.place(x=130, y=3)

    Button(regis, text="light", width=4, height=1, bg="#fff", fg="black" ,command=ganti_regis_light, border=1).place(x=870, y=10)

    #####################################

    def cekSignUp():
        with open('D:/Project Prokom/data.akun.k21.json', 'r') as file:
            data_akun = json.load(file)
        Username = str(user.get())
        Password = str(pw.get())
        confirm_pw = conf_pw.get()
        if Username == "Username" and Password == "Password" and confirm_pw == "Confirm Password":
            messagebox.showerror("Failed", "Harap diisi terlebih dahulu")
        elif Username == "Username":
            messagebox.showerror("Failed", "Username harus diisi!")
        elif Password == confirm_pw:
            for i in range(0, len(data_akun["akun"])):
                if Username == data_akun["akun"][i]["username"]:
                    messagebox.showerror("Error!", "Username yang ada pilih sudah digunakan!")
                    break
            else:
                with open("purchase.history.json", 'r') as file:
                    data = json.loads(file.read())
                data[Username] = []
                with open("purchase.history.json", 'w') as file:
                    file.write(json.dumps(data, sort_keys=True, indent=4, separators=(',', ': ')))
                y = {}
                y.update({"username": Username})
                y.update({"password": Password})
                Addjson(y)
        else:
            messagebox.showerror("Failed", "Password yang Anda masukkan berbeda!")

    #####################################
    
    def Addjson(new_data, filename='data.akun.k21.json'):
        with open(filename,'r+') as file:
            file_data = json.load(file)
            file_data["akun"].append(new_data)
            file.seek(0)
            json.dump(file_data, file, indent = 4)
        messagebox.showinfo("Success", "Akun berhasil dibuat!")
        ganti_login()
                
    ####################################

    def isiuser(e):
        user.delete(0, "end")
    def tidakisiuser(e):
        name = user.get()
        if name == "":
            user.insert(0, "Username")
    user = Entry(frame, width=37, fg="Black", border=0, bg="white", font=("Microsoft YaHei UI Light", 11))
    user.place(x=40, y=80)
    user.insert(0, "Username")
    user.bind("<FocusIn>", isiuser)
    user.bind("<FocusOut>", tidakisiuser)
    Frame(frame, width=295, height=2, bg="black").place(x=40, y=107)

    ####################################

    def isiuser(e):
        pw.delete(0, "end")
        pw.configure(show="*")
    def tidakisiuser(e):
        name = pw.get()
        pw.configure(show="*")
        if name == "":
            pw.configure(show="")
            pw.insert(0, "Password")
    pw = Entry(frame, width=37, fg="Black", border=0, bg="white", font=("Microsoft YaHei UI Light", 11))
    pw.place(x=40, y=140)
    pw.insert(0, "Password")
    pw.bind("<FocusIn>", isiuser)
    pw.bind("<FocusOut>", tidakisiuser)
    Frame(frame, width=295, height=2, bg="black").place(x=40, y=167)

    ####################################

    def isiuser(e):
        conf_pw.delete(0, "end")
        conf_pw.configure(show="*")
    def tidakisiuser(e):
        confPass = conf_pw.get()
        conf_pw.configure(show="*")
        if confPass == "":
            conf_pw.configure(show="")
            conf_pw.insert(0, "Confirm Password")
    conf_pw = Entry(frame, width=37, fg="Black", border=0, bg="white", font=("Microsoft YaHei UI Light", 11))
    conf_pw.place(x=40, y=200)
    conf_pw.insert(0, "Confirm Password")
    conf_pw.bind("<FocusIn>", isiuser)
    conf_pw.bind("<FocusOut>", tidakisiuser)
    Frame(frame, width=295, height=2, bg="black").place(x=40, y=227)

    ####################################

    CTkButton(frame, width=298, height=30, text="Sign In", text_color="black", fg_color="#57a1f8", border_spacing=0, corner_radius=5, hover_color="#0079ff", command=cekSignUp).place(x=39, y=247)
    label_login = Label(frame, text="Sudah memiliki akun?", fg="black", bg="white", font=("Microsoft YaHei UI Light", 9))
    label_login.place(x=95, y=300)
    login_button = Button(frame, width=6, text="Sign In", border=0, fg="#57a1f8", bg="white", cursor="hand2", command=ganti_login)
    login_button.place(x=220, y=300)

    regis.mainloop()


def loginDark():
    global login
    global tgl_banding
    tgl_banding = ""
    login = Tk()
    login.title("K21 Railway Access")
    login.configure(bg="#333333")
    login.geometry("920x500+170+80")
    login.resizable(False, False)

    ##################################

    img = (Image.open("imgsrc\kaicnth.png"))
    img_resize = img.resize((440,230), Image.ANTIALIAS)
    new_image2 = ImageTk.PhotoImage(img_resize)
    Label(login, image=new_image2, bg="#333333").place(x=35, y=127)

    ##################################

    frame = Frame(login, width=350, height=350, bg="#333333")
    frame.place(x=520, y=70)

    ##################################

    heading = Label(frame, text="Sign In", bg="#333333",fg="#57a1f8", font=("Microsoft YaHei UI Light", 20, "bold"))
    heading.place(x=115, y=8)

    Button(login, text="Dark", width=4, height=1, bg="#333333", fg="white" ,command=ganti_login_dark).place(x=870, y=10)
    ##################################

    def cekAkun():
        with open('D:/Project Prokom/data.akun.k21.json', 'r') as file:
            data_akun = json.load(file)
        Username = str(user.get())
        Password = str(pw.get())
        for i in range(0, len(data_akun["akun"])):
            if Username == data_akun["akun"][i]["username"] and Password == data_akun["akun"][i]["password"]:    
                login.destroy()
                mainPage()
                break
        else:
            messagebox.showerror("Login Gagal", "Username atau password salah!")

    ################################## 
    
    def isiuser(e):
        user.delete(0, "end")
    def tidakisiuser(e):
        name = user.get()
        if name == "":
            user.insert(0, "Username")
    user = Entry(frame, width=37, fg="white", border=0, bg="#333333", font=("Microsoft YaHei UI Light", 11))
    user.place(x=30, y=80)
    user.insert(0, "Username")
    user.bind("<FocusIn>", isiuser)
    user.bind("<FocusOut>", tidakisiuser)
    Frame(frame, width=295, height=2, bg="black").place(x=25, y=107)

    #################################
    def isiuser(e):
        pw.delete(0, "end")
        pw.configure(show="*")
    def tidakisiuser(e):
        passw = pw.get()
        pw.configure(show="*")
        if passw == "":
            pw.configure(show="")
            pw.insert(0, "Password")
    pw = Entry(frame, width=37, fg="white", border=0, bg="#333333", font=("Microsoft YaHei UI Light", 11))
    pw.place(x=30, y=150)
    pw.insert(0, "Password")
    pw.bind("<FocusIn>", isiuser)
    pw.bind("<FocusOut>", tidakisiuser)
    Frame(frame, width=295, height=2, bg="black").place(x=25, y=177)

    #################################

    CTkButton(frame, width=298, height=30, text="Sign In", text_color="black", fg_color="#57a1f8", border_spacing=0, corner_radius=5, hover_color="blue", command=cekAkun).place(x=24, y=204)
    label_regis = Label(frame, text="Belum punya akun?", fg="white", bg="#333333", font=("Microsoft YaHei UI Light", 9))
    label_regis.place(x=83, y=250)
    regis_button = Button(frame, width=6, text="Sign Up", border=0, fg="#57a1f8", bg="#333333", cursor="hand2", command=login_regis_dark)
    regis_button.place(x=200, y=250)

    login.mainloop()


def bikinAkunDark():
    global regis
    regis = Tk()
    regis.title("K21 Railway Access")
    regis.geometry("920x500+170+80")
    regis.configure(bg="#333")
    regis.resizable(False, False)

    ####################################
    
    frame = Frame(regis, width=350, height=350, bg="#333")
    frame.place(x=285, y=40)

    ####################################

    heading = Label(frame, text="Sign Up", bg="#333333",fg="#57a1f8", font=("Microsoft YaHei UI Light", 20, "bold"))
    heading.place(x=130, y=3)
    
    
    Button(regis, text="Dark", width=4, height=1, bg="#333333", fg="white" ,command=ganti_regis_dark).place(x=870, y=10)

    #####################################

    def cekSignUp():
        with open('data.akun.k21.json', 'r') as file:
            data_akun = json.load(file)
        Username = user.get()
        Password = pw.get()
        confirm_pw = conf_pw.get()
        if Username == "Username" and Password == "Password" and confirm_pw == "Confirm Password":
            messagebox.showerror("Failed", "Harap diisi terlebih dahulu")
        elif Username == "Username":
            messagebox.showerror("Failed", "Username harus diisi!")
        elif Password == confirm_pw:
            for i in range(0, len(data_akun["akun"])):
                if Username == data_akun["akun"][i]["username"]:
                    messagebox.showerror("Error!", "Username yang ada pilih sudah digunakan!")
                    break
            else:
                y = {}
                y.update({"username": Username})
                y.update({"password": Password})
                Addjson(y)
        else:
            messagebox.showerror("Failed", "Password yang Anda masukkan berbeda!")

    #####################################
    
    def Addjson(new_data, filename='data.akun.k21.json'):
        with open(filename,'r+') as file:
            file_data = json.load(file)
            file_data["akun"].append(new_data)
            file.seek(0)
            json.dump(file_data, file, indent = 4)
        messagebox.showinfo("Success", "Akun berhasil dibuat!")
        ganti_login_light2()
                
    ####################################

    def isiuser(e):
        user.delete(0, "end")
    def tidakisiuser(e):
        name = user.get()
        if name == "":
            user.insert(0, "Username")
    user = Entry(frame, width=37, fg="white", border=0, bg="#333333", font=("Microsoft YaHei UI Light", 11))
    user.place(x=40, y=80)
    user.insert(0, "Username")
    user.bind("<FocusIn>", isiuser)
    user.bind("<FocusOut>", tidakisiuser)
    Frame(frame, width=295, height=2, bg="black").place(x=40, y=107)

    ####################################

    def isiuser(e):
        pw.delete(0, "end")
    def tidakisiuser(e):
        name = pw.get()
        if name == "":
            pw.insert(0, "Password")
    pw = Entry(frame, width=37, fg="white", border=0, bg="#333333", font=("Microsoft YaHei UI Light", 11))
    pw.place(x=40, y=140)
    pw.insert(0, "Password")
    pw.bind("<FocusIn>", isiuser)
    pw.bind("<FocusOut>", tidakisiuser)
    Frame(frame, width=295, height=2, bg="black").place(x=40, y=167)

    ####################################

    def isiuser(e):
        conf_pw.delete(0, "end")
    def tidakisiuser(e):
        name = conf_pw.get()
        if name == "":
            conf_pw.insert(0, "Confirm Password")
    conf_pw = Entry(frame, width=37, fg="white", border=0, bg="#333333", font=("Microsoft YaHei UI Light", 11))
    conf_pw.place(x=40, y=200)
    conf_pw.insert(0, "Confirm Password")
    conf_pw.bind("<FocusIn>", isiuser)
    conf_pw.bind("<FocusOut>", tidakisiuser)
    Frame(frame, width=295, height=2, bg="black").place(x=40, y=227)

    ####################################

    Button(frame, width=42, pady=7, text="Sign Up", bg="#57a1f8", border=0, command=cekSignUp).place(x=38, y=255)
    label_login = Label(frame, text="Sudah memiliki akun?", fg="white", bg="#333333", font=("Microsoft YaHei UI Light", 9))
    label_login.place(x=95, y=300)
    login_button = Button(frame, width=6, text="Sign In", border=0, fg="#57a1f8", bg="#333333", cursor="hand2", command=ganti_login_light2)
    login_button.place(x=220, y=300)

    regis.mainloop()


def ganti_regis_dark():
    regis.destroy()
    bikinAkun()
    
def ganti_regis_light():
    regis.destroy()
    bikinAkunDark()

def login_regis_dark():
    login.destroy()
    bikinAkunDark()
    
def ganti_login_dark():
    login.destroy()
    loginAkun()
    
def ganti_login_light():
    login.destroy()
    loginDark()

def ganti_login_dark2():
    regis.destroy()
    loginAkun()
    
def ganti_login_light2():
    regis.destroy()
    loginDark()
    
def ganti_login():
    regis.destroy()
    loginAkun()

def ganti_regis():
    login.destroy()
    bikinAkun()

def ticketPage():
    global ticket
    main.destroy()
    with open("purchase.history.json", 'r') as file:
        history = json.loads(file.read())
    ticket = Tk()
    ticket.geometry("920x500+170+80")
    ticket.resizable(False, False)
    ticket.title("K21 Railway Access")
    ticket.configure(bg="#fff")
    style = ttk.Style()
    style.theme_use('default')
    style.configure("Vertical.TScrollbar", background="#57a1f8", bordercolor="#000000", arrowcolor="#fff", troughcolor="white")

    wrapper = CTkFrame(ticket)
    wrapper.pack(side=BOTTOM, fill=BOTH, expand=YES, pady=30, padx=250)
    heading = Frame(ticket, width=920, height=30, bg="#57a1f8")
    heading.place(x=0, y=0)
    img = (Image.open("imgsrc\kembali.png"))
    img_resize = img.resize((23,23), Image.ANTIALIAS)
    button_img = ImageTk.PhotoImage(img_resize)
    button_back = CTkButton(master=heading, text="",image=button_img, width=0, height=0, cursor="hand2", fg_color="#57a1f8", hover_color="#57a1f8", command=backTicket)
    button_back.place(x=-2, y=-1)

    mycanvas = Canvas(wrapper, bg="#eaeaea")
    mycanvas.pack(side=LEFT, fill=BOTH, expand="yes")
    mycanvas.bind("<Configure>", lambda e: mycanvas.configure(scrollregion = mycanvas.bbox("all")))

    myframe = Frame(mycanvas, bg="#eaeaea")
    mycanvas.create_window((0,0), window=myframe, anchor="nw")
    
    img = (Image.open("imgsrc\k21.png"))
    img_resize = img.resize((170,50), Image.ANTIALIAS)
    logok21 = ImageTk.PhotoImage(img_resize)
    img = (Image.open("imgsrc\kananhtm.png"))
    img_resize = img.resize((15,15), Image.ANTIALIAS)
    arah = ImageTk.PhotoImage(img_resize)
    
    if len(history[Username]) > 0:
        yscrollbar = ttk.Scrollbar(wrapper, orient=VERTICAL, cursor="hand2",command=mycanvas.yview)
        yscrollbar.pack(side=RIGHT, fill=BOTH)
        mycanvas.configure(yscrollcommand=yscrollbar.set)
        for i in range(0, len(history[Username])):
            canvasHistory = CTkCanvas(myframe, width=393, height=170, bg="#fff")
            canvasHistory.pack(padx=5, pady=7)
            Label(canvasHistory, image=logok21, bg="#fff").place(x=-38, y=7)
            frameH = CTkFrame(canvasHistory, width=60, height=30, fg_color="green", corner_radius=8)
            frameH.place(x=320, y=16)
            Label(frameH, text="LUNAS", font=("Calibri", 12, "bold"), fg="#fff", bg="green").place(x=5, y=2)
            Label(canvasHistory, text="Kode Pemesanan : {}".format(history[Username][i]["Kode"]), bg="#fff", font=("Arial", 12)).place(x=16, y=53)
            Frame(canvasHistory, width=353, height=1, bg="#999999").place(x=20, y=85)
            Label(canvasHistory, text="{}\n                                    ".format(history[Username][i]["Kota Asal"]), bg="#fff", justify="left", font=("Calibri", 10)).place(x=18, y=88)
            Label(canvasHistory, text="{}\n                                    ".format(history[Username][i]["Kota Tujuan"]), bg="#fff", justify="right", font=("Calibri", 10)).place(x=260, y=88)
            Label(canvasHistory, text="{}\n                  ".format(history[Username][i]["Waktu Berangkat"]), font=("Calibri", 20), bg="#fff", justify="left").place(x=18, y=108)
            Label(canvasHistory, text="{}\n                  ".format(history[Username][i]["Waktu Sampai"]), font=("Calibri", 20), bg="#fff", justify="right").place(x=260, y=108)
            Label(canvasHistory, image=arah, bg="#fff").place(x=180, y=115 )
    else:
        CTkButton(mycanvas, width=400, height=200, fg_color="#fff", bg_color="#eaeaea", text_color="black", hover_color="#fff", corner_radius=10, border_spacing=0, text="Tidak ada riwayat", font=("Calibri", 16, "bold")).pack(expand=True)
        
    ticket.mainloop()

def backTicket():
    ticket.destroy()
    mainPage()

def mainPage():
    global main
    global Asal
    global Tujuan
    global Tanggal_pilih
    global banyakPenumpang
    system("cls")
    main = Tk()
    main.geometry("920x500+170+80")
    main.resizable(False, False)
    main.configure(bg="#dfdfde")
    main.title("K21 Railway Access")

    def toggle_menu():
        def logout():
            def iya():
                keluar.destroy()
                main.destroy()
                loginAkun()
            def engga():
                keluar.destroy()
                main.after(400)
                main.deiconify()
            main.withdraw()
            keluar = Tk()
            keluar.geometry("200x80+550+270")
            keluar.resizable(False, False)
            Label(keluar, text="Apakah Anda ingin keluar?").place(x=27, y=10)
            CTkButton(keluar, width=47, height=28, text="Ya", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=7, cursor="hand2", command=iya).place(x=35, y=50)
            CTkButton(keluar, width=40, height=28, text="Tidak", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=7, cursor="hand2", command=engga).place(x=120, y=50)
             
            
        f1 = Frame(main, width=200, height=500, bg="#57a1f8")
        f1.place(x=0, y=0)
        f1.grab_set()
        
        img = (Image.open("imgsrc\pp.png"))
        img_resize = img.resize((70,70), Image.ANTIALIAS)
        pp_img = ImageTk.PhotoImage(img_resize)
        CTkLabel(f1, image=pp_img, text="", bg_color="#57a1f8").place(x=60, y=50)
        Label(f1, text=f"{Username}\n                                   ",
              fg="black", 
              bg="#57a1f8", font=("Arial", 12),
              justify="center").place(x=23, y=130)
        
        img = (Image.open("imgsrc\k21paper2.png"))
        img_resize = img.resize((20,25), Image.ANTIALIAS)
        paper = ImageTk.PhotoImage(img_resize)
        CTkButton(f1, width=180, height=30, image=paper, compound="left", text="Riwayat Pembelian", fg_color="#57a1f8", text_color="black", corner_radius=10, cursor="hand2", hover_color="#2f58cd", command=ticketPage).place(x=10, y=190)
        img = (Image.open("imgsrc\keluar.png"))
        img_resize = img.resize((20,25), Image.ANTIALIAS)
        logot = ImageTk.PhotoImage(img_resize)
        CTkButton(f1, image=logot, width=40, height=30, compound="left", text="Keluar", fg_color="#57a1f8", text_color="black", corner_radius=10, cursor="hand2", hover_color="#2f58cd", command=logout).place(x=5, y=464)
        
        
        def delete():
            f1.destroy()
            
        img = (Image.open("imgsrc\exit.png"))
        img_resize = img.resize((20,20), Image.ANTIALIAS)
        exit_img = ImageTk.PhotoImage(img_resize)
        CTkButton(f1, image=exit_img, width=0, height=0,
                  text="", corner_radius=100, fg_color="#57a1f8",
                  hover_color="#57a1f8", bg_color="#57a1f8", 
                  border_spacing=0, command=delete).place(x=10, y=17)

    def cekTanggal():
        global tanggal_hari_ini
        global tgl_banding
        tanggal_hari_ini    = datetime.date.today()
        tgl_pilih           = cal.get_date()
        tgl_pisah           = tgl_pilih.split('-')
        tgl_banding         = datetime.date(int(tgl_pisah[0]), int(tgl_pisah[1]), int(tgl_pisah[2]))
        if tgl_banding < tanggal_hari_ini:
            messagebox.showerror("Error!", "Tidak bisa memesan tiket untuk hari yang telah terlewat!")
            kalender.destroy()
        elif tgl_banding > tanggal_hari_ini + datetime.timedelta(days=30):
            messagebox.showerror("Error!", "Tiket belum tersedia!")
            kalender.destroy()
        else:
            kalender.destroy()
            gantiTextTgl()

    def pilihTanggal():
        global kalender
        global cal
        kalender = Tk()
        kalender.title("Pilih Tanggal")
        kalender.geometry("250x250+500+200")
        kalender.resizable(False, False)
        cal = Calendar(kalender, selectmode="day", date_pattern="yyyy-mm-dd")
        cal.pack(pady=10)
        select_btn = Button(kalender, text="Pilih", command=cekTanggal)
        select_btn.pack()
        kalender.mainloop()
        
    def gantiTextTgl():
        Tanggal_pilih.configure(bg="#fff", fg="black", text=f"{tgl_banding}")
    
    def cekPilihanUser():
        global rute
        global jumlahPenumpang
        global userAsal
        global userTujuan
        global userTanggal
        userAsal = Asal.get()
        userTujuan = Tujuan.get()
        userJumlah = banyakPenumpang.get()
        if bool(userAsal) == True and bool(userTujuan) == True:
            if userAsal != userTujuan:
                if bool(tgl_banding) == True:
                    userTanggal = tgl_banding
                    if bool(userJumlah) == True:
                        rute = "{} - {}".format(userAsal, userTujuan)
                        jumlahPenumpang = int(userJumlah)
                        main.withdraw() 
                        schedulPage()
                    else:
                        messagebox.showinfo("Error", "Harap isi banyak penumpang!")
                elif bool(userJumlah) == True:
                    jumlahPenumpang = int(userJumlah)
                    if bool(tgl_banding) == True:
                        rute = "{} - {}".format(userAsal, userTujuan)
                        userTanggal = tgl_banding
                        main.withdraw() 
                        schedulPage()
                    else:
                        messagebox.showinfo("Error", "Harap pilih tanggal terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap pilih tanggal dan banyak penumpang terlebih dahulu")
            else:
                messagebox.showinfo("Error", "Tidak bisa memesan untuk kota yang sama!")
                Asal.set("")
                Tujuan.set("")
        elif bool(userAsal) == True or bool(userTujuan) == True:
            messagebox.showinfo("Error", "Harap pilih kota asal dan kota tujuan!")
        else:
            messagebox.showinfo("Error", "Harap pilih kota asal dan kota tujuan!")
            Asal.set("")
            Tujuan.set("")
            
    
    frame_top = Frame(main, width=920, height=67, bg="#2f58cd")
    frame_top.pack(side=TOP)

    img = (Image.open("imgsrc\k21.png"))
    img_resize = img.resize((250,90), Image.ANTIALIAS)
    new_image1 = ImageTk.PhotoImage(img_resize)
    Label(frame_top, image=new_image1, bg="#2f58cd").place(x=325, y=-10)

    frame1 = CTkFrame(main, width=450, height=400, fg_color="#fff", corner_radius=10)
    frame1.place(x=230, y=75)

    img = (Image.open("imgsrc\kanan.png"))
    img_resize = img.resize((30,25), Image.ANTIALIAS)
    new_image2 = ImageTk.PhotoImage(img_resize)
    Label(frame1, image=new_image2, bg="#fff").place(x=211, y=59)

    heading = Label(frame1, text="KA Antar Kota", bg="#fff", fg="black", font=("Verdana", 12))
    heading.place(x=168, y=10)

    Label_asal = Label(frame1, text="Asal", bg="#fff", fg="black", font=("Verdana", 10))
    Label_asal.place(x=35, y=60)
    Frame(frame1, width=163, height=1, bg="#a6a9b6", ).place(x=37, y=122)

    Label_tujuan = Label(frame1, text="Tujuan", bg="#fff", fg="black", font=("Verdana", 10))
    Label_tujuan.place(x=365, y=60)
    Frame(frame1, width=163, height=1, bg="#a6a9b6", ).place(x=253, y=122)

    Label_tgl_berangkat = Label(frame1, text="Tanggal Berangkat", bg="#fff", fg="black", font=("Verdana", 10))
    Label_tgl_berangkat.place(x=35, y=160)
    Frame(frame1, width=163, height=1, bg="#a6a9b6", ).place(x=37, y=217)

    Label_banyak_penumpang = Label(frame1, text="Banyak Penumpang", bg="#fff", fg="black", font=("Verdana", 10))
    Label_banyak_penumpang.place(x=283, y=160)
    Frame(frame1, width=163, height=1, bg="#a6a9b6", ).place(x=253, y=217)

    Kota = ["Jakarta", "Bandung", "Cirebon", "Purwokerto", "Yogyakarta", "Semarang", "Madiun", "Surabaya", "Jember"]

    Asal = StringVar(main)
    Asal.set("")
    OptionMenu_asal = OptionMenu(frame1, Asal,*Kota)
    OptionMenu_asal.configure(border=0, bg="#fff", width=20, fg="black", cursor="hand2")
    OptionMenu_asal.place(x=37, y=90)

    Tujuan = StringVar(main)
    Tujuan.set("")
    OptionMenu_tujuan = OptionMenu(frame1, Tujuan,*Kota)
    OptionMenu_tujuan.configure(border=0, bg="#fff", width=20, cursor="hand2")
    OptionMenu_tujuan.place(x=255, y=90)

    Tanggal_pilih = Button(frame1, bg="#fff", text="", width=22, border=0, command=pilihTanggal, cursor="hand2")
    Tanggal_pilih.place(x=36, y=190)

    jumlah = [1, 2, 3, 4, 5]

    banyakPenumpang = StringVar(main)
    banyakPenumpang.set("")
    OptionMenu_banyak_penumpang = OptionMenu(frame1, banyakPenumpang, *jumlah)
    OptionMenu_banyak_penumpang.configure(border=0, bg="#fff", width=20, fg="black", cursor="hand2")
    OptionMenu_banyak_penumpang.place(x=255, y=185)
    
    img = (Image.open("imgsrc\strip.png"))
    img_resize = img.resize((40,40), Image.ANTIALIAS)
    toggle_img = ImageTk.PhotoImage(img_resize)
    CTkButton(main, width=0, height=0, text="", corner_radius=100, image=toggle_img, fg_color="#2f58cd", hover_color="#2f58cd", bg_color="#2f58cd", border_spacing=0, command=toggle_menu).place(x=0, y=10)
    
    CTkButton(frame1, width=383, height=32, text="Cari Jadwal", text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, font=("Microsoft YaHei UI Heavy", 13), cursor="hand2", command=cekPilihanUser).place(x=35, y=300)
    system("cls")
    main.mainloop() 
  
def transisiBack():
    schedul.destroy()
    main.after(600)
    main.deiconify()
  
def schedulPage():
    global schedul
    schedul = Toplevel()
    schedul.geometry("920x500+170+80")
    schedul.resizable(False, False)
    schedul.title("K21 Railway Access")
    schedul.configure(bg="#fff")
    style = ttk.Style()
    style.theme_use('default')
    style.configure("Vertical.TScrollbar", background="#57a1f8", bordercolor="#000000", arrowcolor="#fff", troughcolor="white")

    wrapper = CTkFrame(schedul)
    wrapper.pack(side=BOTTOM, fill=BOTH, expand=YES, pady=30, padx=250)
    heading = Frame(schedul, width=920, height=30, bg="#57a1f8")
    heading.place(x=0, y=0)
    img = (Image.open("imgsrc\kembali.png"))
    img_resize = img.resize((23,23), Image.ANTIALIAS)
    button_img = ImageTk.PhotoImage(img_resize)
    button_back = CTkButton(master=heading, text="",image=button_img, width=0, height=0, cursor="hand2", command=transisiBack, fg_color="#57a1f8", hover_color="#57a1f8")
    button_back.place(x=-2, y=-1)
    heading_text = Label(heading, bg="#57a1f8", fg="black", text=f"Schedul {rute} at {tgl_banding}")
    heading_text.place(x=348, y=4)

    mycanvas = Canvas(wrapper, bg="#dde6de")
    mycanvas.pack(side=LEFT, fill=BOTH, expand="yes")

    yscrollbar = ttk.Scrollbar(wrapper, orient=VERTICAL, cursor="hand2",command=mycanvas.yview)
    yscrollbar.pack(side=RIGHT, fill=BOTH)

    mycanvas.configure(yscrollcommand=yscrollbar.set)
    mycanvas.bind("<Configure>", lambda e: mycanvas.configure(scrollregion = mycanvas.bbox("all")))

    myframe = Frame(mycanvas, bg="#dde6de")
    mycanvas.create_window((0,0), window=myframe, anchor="nw")

    def userPilih1():
        global namaKereta
        global hargaKereta
        global waktuBerangkat
        global waktuSampai
        global kelasKereta
        namaKereta      = jadwalKereta[rute][0]["nama"]
        hargaKereta     = jadwalKereta[rute][0]["harga"]
        kelasKereta     = jadwalKereta[rute][0]["kelas"]
        waktuBerangkat  = jadwalKereta[rute][0]["waktu_awal"]
        waktuSampai     = jadwalKereta[rute][0]["waktu_akhir"]
        schedul.destroy()
        cekJumlahPenumpang()
    def userPilih2():
        global namaKereta
        global hargaKereta
        global waktuBerangkat
        global waktuSampai
        global kelasKereta
        namaKereta      = jadwalKereta[rute][1]["nama"]
        hargaKereta     = jadwalKereta[rute][1]["harga"]
        kelasKereta     = jadwalKereta[rute][1]["kelas"]
        waktuBerangkat  = jadwalKereta[rute][1]["waktu_awal"]
        waktuSampai     = jadwalKereta[rute][1]["waktu_akhir"]
        schedul.destroy()
        cekJumlahPenumpang()
    def userPilih3():
        global namaKereta
        global hargaKereta
        global waktuBerangkat
        global waktuSampai
        global kelasKereta
        namaKereta      = jadwalKereta[rute][2]["nama"]
        hargaKereta     = jadwalKereta[rute][2]["harga"]
        kelasKereta     = jadwalKereta[rute][2]["kelas"]
        waktuBerangkat  = jadwalKereta[rute][2]["waktu_awal"]
        waktuSampai     = jadwalKereta[rute][2]["waktu_akhir"]
        schedul.destroy()
        cekJumlahPenumpang()
    def userPilih4():
        global namaKereta
        global hargaKereta
        global waktuBerangkat
        global waktuSampai
        global kelasKereta
        namaKereta      = jadwalKereta[rute][3]["nama"]
        hargaKereta     = jadwalKereta[rute][3]["harga"]
        kelasKereta     = jadwalKereta[rute][3]["kelas"]
        waktuBerangkat  = jadwalKereta[rute][3]["waktu_awal"]
        waktuSampai     = jadwalKereta[rute][3]["waktu_akhir"]
        schedul.destroy()
        cekJumlahPenumpang()
    def userPilih5():
        global namaKereta
        global hargaKereta
        global waktuBerangkat
        global waktuSampai
        global kelasKereta
        namaKereta      = jadwalKereta[rute][4]["nama"]
        hargaKereta     = jadwalKereta[rute][4]["harga"]
        kelasKereta     = jadwalKereta[rute][4]["kelas"]
        waktuBerangkat  = jadwalKereta[rute][4]["waktu_awal"]
        waktuSampai     = jadwalKereta[rute][4]["waktu_akhir"]
        schedul.destroy()
        cekJumlahPenumpang()
    def userPilih6():
        global namaKereta
        global hargaKereta
        global waktuBerangkat
        global waktuSampai
        global kelasKereta
        namaKereta      = jadwalKereta[rute][5]["nama"]
        hargaKereta     = jadwalKereta[rute][5]["harga"]
        kelasKereta     = jadwalKereta[rute][5]["kelas"]
        waktuBerangkat  = jadwalKereta[rute][5]["waktu_awal"]
        waktuSampai     = jadwalKereta[rute][5]["waktu_akhir"]
        schedul.destroy()
        cekJumlahPenumpang()
    def userPilih7():
        global namaKereta
        global hargaKereta
        global waktuBerangkat
        global waktuSampai
        global kelasKereta
        namaKereta      = jadwalKereta[rute][6]["nama"]
        hargaKereta     = jadwalKereta[rute][6]["harga"]
        kelasKereta     = jadwalKereta[rute][6]["kelas"]
        waktuBerangkat  = jadwalKereta[rute][6]["waktu_awal"]
        waktuSampai     = jadwalKereta[rute][6]["waktu_akhir"]
        schedul.destroy()
        cekJumlahPenumpang()
    def userPilih8():
        global namaKereta
        global hargaKereta
        global waktuBerangkat
        global waktuSampai
        global kelasKereta
        namaKereta      = jadwalKereta[rute][7]["nama"]
        hargaKereta     = jadwalKereta[rute][7]["harga"]
        kelasKereta     = jadwalKereta[rute][7]["kelas"]
        waktuBerangkat  = jadwalKereta[rute][7]["waktu_awal"]
        waktuSampai     = jadwalKereta[rute][7]["waktu_akhir"]
        schedul.destroy()
        cekJumlahPenumpang()
    def userPilih9():
        global namaKereta
        global hargaKereta
        global waktuBerangkat
        global waktuSampai
        global kelasKereta
        namaKereta      = jadwalKereta[rute][8]["nama"]
        hargaKereta     = jadwalKereta[rute][8]["harga"]
        kelasKereta     = jadwalKereta[rute][8]["kelas"]
        waktuBerangkat  = jadwalKereta[rute][8]["waktu_awal"]
        waktuSampai     = jadwalKereta[rute][8]["waktu_akhir"]
        schedul.destroy()
        cekJumlahPenumpang()
        
    try:
        CTkButton(myframe,cursor="hand2", text="{}\n\n{}\n\n{}\n\n{}".format(jadwalKereta[rute][0]["nama"], jadwalKereta[rute][0]["kelas"]+"      "+jadwalKereta[rute][0]["harga"]+"/pax", "Waktu Berangkat                Waktu Sampai",jadwalKereta[rute][0]["waktu_awal"]+"                 ->              "+jadwalKereta[rute][0]["waktu_akhir"]), width=394, height=130, border_spacing=0, fg_color="#fff", text_color="black", hover_color="#efefef", command=userPilih1).pack(expand=YES, pady=6, padx=5)
    except:
        CTkButton(myframe, text="Jadwal Kosong", text_color="black", fg_color="#efefef", hover_color="#efefef", width=394, height=130, border_spacing=0).pack(expand=YES, pady=6, padx=5)
    try:
        CTkButton(myframe,cursor="hand2", text="{}\n\n{}\n\n{}\n\n{}".format(jadwalKereta[rute][1]["nama"], jadwalKereta[rute][1]["kelas"]+"      "+jadwalKereta[rute][1]["harga"]+"/pax", "Waktu Berangkat                Waktu Sampai",jadwalKereta[rute][1]["waktu_awal"]+"                 ->              "+jadwalKereta[rute][1]["waktu_akhir"]), width=394, height=130, border_spacing=0, fg_color="#fff", text_color="black", hover_color="#efefef", command=userPilih2).pack(expand=YES, pady=6, padx=5)
    except:
        CTkButton(myframe, text="Jadwal Kosong", text_color="black", fg_color="#efefef", hover_color="#efefef", width=394, height=130, border_spacing=0).pack(expand=YES, pady=6, padx=5)
    try:
        CTkButton(myframe,cursor="hand2", text="{}\n\n{}\n\n{}\n\n{}".format(jadwalKereta[rute][2]["nama"], jadwalKereta[rute][2]["kelas"]+"      "+jadwalKereta[rute][2]["harga"]+"/pax", "Waktu Berangkat                Waktu Sampai",jadwalKereta[rute][2]["waktu_awal"]+"                 ->              "+jadwalKereta[rute][2]["waktu_akhir"]), width=394, height=130, border_spacing=0, fg_color="#fff", text_color="black", hover_color="#efefef", command=userPilih3).pack(expand=YES, pady=6, padx=5)
    except:
        CTkButton(myframe, text="Jadwal Kosong", text_color="black", fg_color="#efefef", hover_color="#efefef", width=394, height=130, border_spacing=0).pack(expand=YES, pady=6, padx=5)
    try:
        CTkButton(myframe,cursor="hand2", text="{}\n\n{}\n\n{}\n\n{}".format(jadwalKereta[rute][3]["nama"], jadwalKereta[rute][3]["kelas"]+"      "+jadwalKereta[rute][3]["harga"]+"/pax", "Waktu Berangkat                Waktu Sampai",jadwalKereta[rute][3]["waktu_awal"]+"                 ->              "+jadwalKereta[rute][3]["waktu_akhir"]), width=394, height=130, border_spacing=0, fg_color="#fff", text_color="black", hover_color="#efefef", command=userPilih4).pack(expand=YES, pady=6, padx=5)
    except:
        CTkButton(myframe, text="Jadwal Kosong", text_color="black", fg_color="#efefef", hover_color="#efefef", width=394, height=130, border_spacing=0).pack(expand=YES, pady=6, padx=5)
    try:
        CTkButton(myframe,cursor="hand2", text="{}\n\n{}\n\n{}\n\n{}".format(jadwalKereta[rute][4]["nama"], jadwalKereta[rute][4]["kelas"]+"      "+jadwalKereta[rute][4]["harga"]+"/pax", "Waktu Berangkat                Waktu Sampai",jadwalKereta[rute][4]["waktu_awal"]+"                 ->              "+jadwalKereta[rute][4]["waktu_akhir"]), width=394, height=130, border_spacing=0, fg_color="#fff", text_color="black", hover_color="#efefef", command=userPilih5).pack(expand=YES, pady=6, padx=5)
    except:
        CTkButton(myframe, text="Jadwal Kosong", text_color="black", fg_color="#efefef", hover_color="#efefef", width=394, height=130, border_spacing=0).pack(expand=YES, pady=6, padx=5)
    try:
        CTkButton(myframe,cursor="hand2", text="{}\n\n{}\n\n{}\n\n{}".format(jadwalKereta[rute][5]["nama"], jadwalKereta[rute][5]["kelas"]+"      "+jadwalKereta[rute][5]["harga"]+"/pax", "Waktu Berangkat                Waktu Sampai",jadwalKereta[rute][5]["waktu_awal"]+"                 ->              "+jadwalKereta[rute][5]["waktu_akhir"]), width=394, height=130, border_spacing=0, fg_color="#fff", text_color="black", hover_color="#efefef", command=userPilih6).pack(expand=YES, pady=6, padx=5)
    except:
        CTkButton(myframe, text="Jadwal Kosong", text_color="black", fg_color="#efefef", hover_color="#efefef", width=394, height=130, border_spacing=0).pack(expand=YES, pady=6, padx=5)    
    try:
        CTkButton(myframe,cursor="hand2", text="{}\n\n{}\n\n{}\n\n{}".format(jadwalKereta[rute][6]["nama"], jadwalKereta[rute][6]["kelas"]+"      "+jadwalKereta[rute][6]["harga"]+"/pax", "Waktu Berangkat                Waktu Sampai",jadwalKereta[rute][6]["waktu_awal"]+"                 ->              "+jadwalKereta[rute][6]["waktu_akhir"]), width=394, height=130, border_spacing=0, fg_color="#fff", text_color="black", hover_color="#efefef", command=userPilih7).pack(expand=YES, pady=6, padx=5)
    except:
        CTkButton(myframe, text="Jadwal Kosong", text_color="black", fg_color="#efefef", hover_color="#efefef", width=394, height=130, border_spacing=0).pack(expand=YES, pady=6, padx=5)
    try:
        CTkButton(myframe,cursor="hand2", text="{}\n\n{}\n\n{}\n\n{}".format(jadwalKereta[rute][7]["nama"], jadwalKereta[rute][7]["kelas"]+"      "+jadwalKereta[rute][7]["harga"]+"/pax", "Waktu Berangkat                Waktu Sampai",jadwalKereta[rute][7]["waktu_awal"]+"                 ->              "+jadwalKereta[rute][7]["waktu_akhir"]), width=394, height=130, border_spacing=0, fg_color="#fff", text_color="black", hover_color="#efefef", command=userPilih8).pack(expand=YES, pady=6, padx=5)
    except:
        CTkButton(myframe, text="Jadwal Kosong", text_color="black", fg_color="#efefef", hover_color="#efefef", width=394, height=130, border_spacing=0).pack(expand=YES, pady=6, padx=5)
    try:
        CTkButton(myframe,cursor="hand2", text="{}\n\n{}\n\n{}\n\n{}".format(jadwalKereta[rute][8]["nama"], jadwalKereta[rute][8]["kelas"]+"      "+jadwalKereta[rute][8]["harga"]+"/pax", "Waktu Berangkat                Waktu Sampai",jadwalKereta[rute][8]["waktu_awal"]+"                 ->              "+jadwalKereta[rute][8]["waktu_akhir"]), width=394, height=130, border_spacing=0, fg_color="#fff", text_color="black", hover_color="#efefef", command=userPilih9).pack(expand=YES, pady=6, padx=5)
    except:
        CTkButton(myframe, text="Jadwal Kosong", text_color="black", fg_color="#efefef", hover_color="#efefef", width=394, height=130, border_spacing=0).pack(expand=YES, pady=6, padx=5)

    system("cls")

    schedul.mainloop()

def transisiSchedulIdentity():
    iden.destroy()
    schedulPage()

def cekJumlahPenumpang():
    global namaPenumpang1
    global namaPenumpang2
    global namaPenumpang3
    global namaPenumpang4
    global namaPenumpang5
    if jumlahPenumpang == 1:
        namaPenumpang1 = ""
        penumpangSatu()
    elif jumlahPenumpang == 2:
        namaPenumpang1 = ""
        namaPenumpang2 = ""
        penumpangDua()
    elif jumlahPenumpang == 3:
        namaPenumpang1 = ""
        namaPenumpang2 = ""
        namaPenumpang3 = ""
        penumpangTiga()
    elif jumlahPenumpang == 4:
        namaPenumpang1 = ""
        namaPenumpang2 = ""
        namaPenumpang3 = ""
        namaPenumpang4 = ""
        penumpangEmpat()
    else:
        namaPenumpang1 = ""
        namaPenumpang2 = ""
        namaPenumpang3 = ""
        namaPenumpang4 = ""
        namaPenumpang5 = ""
        penumpangLima()

def transisi1():
    iden.withdraw()
    iden.after(500)
    isiIdentitas1()
def transisi2():
    iden.withdraw()
    iden.after(500)
    isiIdentitas2()
def transisi3():
    iden.withdraw()
    iden.after(500)
    isiIdentitas3()
def transisi4():
    iden.withdraw()
    iden.after(500)
    isiIdentitas4()
def transisi5():
    iden.withdraw()
    iden.after(500)
    isiIdentitas5()
def transisi12():
    isi.destroy()
    iden.after(1000)
    iden.deiconify()
def transisi22():
    isi.destroy()
    iden.after(1000)
    iden.deiconify()
def transisi32():
    isi.destroy()
    iden.after(1000)
    iden.deiconify()
def transisi42():
    isi.destroy()
    iden.after(1000)
    iden.deiconify()
def transisi52():
    isi.destroy()
    iden.after(1000)
    iden.deiconify()

def isiIdentitas1():
    global isi
    global nama_user
    isi = Toplevel()
    isi.geometry("920x500+170+80")
    isi.resizable(False, False)
    isi.configure(bg="#dfdfde")
    isi.title("K21 Railway Access")
    
    def gantiButton1():
        global namaPenumpang1
        global emailPenumpang1
        global noHpPenumpang1
        global tipePenumpang1
        namaPenumpang1 = nama_user.get()
        emailPenumpang1 = email_user.get()
        noHpPenumpang1 = nohp_user.get()
        tipePenumpang1 = tipe_penumpang.get()
        if bool(namaPenumpang1) == True:    
            if noHpPenumpang1.isnumeric() == True:
                if bool(emailPenumpang1) == True:
                    if bool(tipePenumpang1) == True:    
                        identitas1.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang1+"   /   "+tipePenumpang1, emailPenumpang1, noHpPenumpang1))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap pilih tipe penumpang terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi email terlebih dahulu!")
            elif bool(emailPenumpang1) == True:
                if noHpPenumpang1.isnumeric() == True:
                    if bool(tipePenumpang1) == True:
                        identitas1.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang1+"   /   "+tipePenumpang1, emailPenumpang1, noHpPenumpang1))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap pilih tipe penumpang terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi No. HP terlebih dahulu!")
            elif bool(noHpPenumpang1) == True:
                if bool(emailPenumpang1) == True:
                    if bool(tipePenumpang1) == True:
                        identitas1.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang1+"   /   "+tipePenumpang1, emailPenumpang1, noHpPenumpang1))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap pilih tipe penumpang terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi email terlebih dahulu!")
            elif bool(tipePenumpang1) == True:
                if bool(noHpPenumpang1) == True:
                    if bool(emailPenumpang1) == True:
                        identitas1.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang1+"   /   "+tipePenumpang1, emailPenumpang1, noHpPenumpang1))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap isi email terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi No. HP terlebih dahulu!")
            else:
                messagebox.showerror("Error!", "Harap isi identitas terlebih dahulu!")
        else:
            messagebox.showerror("Error!", "Harap isi identitas terlebih dahulu!")
            
    img = (Image.open("imgsrc\chair.png"))
    img_resize = img.resize((28,38), Image.LANCZOS)
    kursi = ImageTk.PhotoImage(img_resize)
    Label(isi, image=kursi, bg="#dfdfde").place(x=222, y=28)
    
    Label(isi, text="Penumpang 1", font=("vernada", 14), bg="#dfdfde").place(x=260, y=35)
    wrapper = CTkFrame(isi, width=480, height=350, fg_color="#f5f5f5", corner_radius=10)
    wrapper.place(x=220, y=75)
    
    nama_kereta = Label(wrapper, fg="#57a1f8", bg="#f5f5f5",font=("bold", 19), text="{}".format(namaKereta))
    nama_kereta.place(x=19, y=14)
    kelas_kereta = Label(wrapper,  fg="black", bg="#f5f5f5",font=("bold", 9), text="{}".format(kelasKereta))
    kelas_kereta.place(x=21, y=50)
    harga_kereta = Label(wrapper, fg="black", bg="#f5f5f5",font=("bold", 10), text="{}".format(hargaKereta))
    harga_kereta.place(x=394, y=23)
    
    Label(wrapper, text="Nama Lengkap", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=21, y=95)
    nama_user = Entry(wrapper, width=54, fg="#333333", border=0, bg="#f5f5f5", font=("Vernada", 11))
    nama_user.place(x=24, y=127)
    Frame(wrapper, width=430, height=1, bg="#999999").place(x=25, y=149)
    
    Label(wrapper, text="Email", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=21, y=163)
    email_user = Entry(wrapper, width=54, fg="#333333", border=0, bg="#f5f5f5", font=("Vernada", 11))
    email_user.place(x=24, y=195)
    Frame(wrapper, width=430, height=1, bg="#999999").place(x=25, y=217)
    
    Label(wrapper, text="No. Handphone", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=21, y=231)
    nohp_user = Entry(wrapper, width=27, fg="#333333", border=0, bg="#f5f5f5", font=("Vernada", 11))
    nohp_user.place(x=24, y=263)
    Frame(wrapper, width=205, height=1, bg="#999999").place(x=25, y=285)
    
    Label(wrapper, text="Tipe Penumpang", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=334, y=231)
    Frame(wrapper, width=100, height=1, bg="#999999").place(x=354, y=285)
    Tipe = ["Dewasa", "Pelajar"]
    tipe_penumpang = StringVar(isi)
    tipe_penumpang.set("")
    OptionMenu_tipe = OptionMenu(wrapper, tipe_penumpang, *Tipe)
    OptionMenu_tipe.configure(border=0, bg="#f5f5f5", width=8, cursor="hand2")
    OptionMenu_tipe.place(x=366, y=255)
    
    img = (Image.open("imgsrc\kembali.png"))
    img_resize = img.resize((23,23), Image.LANCZOS)
    button_img = ImageTk.PhotoImage(img_resize)
    CTkButton(isi, text="", image=button_img, width=0, height=0, cursor="hand2", fg_color="#dfdfde", hover_color="#dfdfde", command=transisi12).place(x=0, y=0)
    
    CTkButton(isi, width=481, height=30, text="Tambahkan", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=10, command=gantiButton1, cursor="hand2").place(x=220, y=435)
    system("cls")

    isi.mainloop()
    
def isiIdentitas2():
    global isi
    global nama_user
    isi = Toplevel()
    isi.geometry("920x500+170+80")
    isi.resizable(False, False)
    isi.configure(bg="#dfdfde")
    isi.title("K21 Railway Access")
    
    def gantiButton2():
        global namaPenumpang2
        global emailPenumpang2
        global noHpPenumpang2
        global tipePenumpang2
        namaPenumpang2 = nama_user.get()
        emailPenumpang2 = email_user.get()
        noHpPenumpang2 = nohp_user.get()
        tipePenumpang2 = tipe_penumpang.get()
        if bool(namaPenumpang2) == True:    
            if noHpPenumpang2.isnumeric() == True:
                if bool(emailPenumpang2) == True:
                    if bool(tipePenumpang2) == True:    
                        identitas2.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang2+"   /   "+tipePenumpang2, emailPenumpang2, noHpPenumpang2))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap pilih tipe penumpang terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi email terlebih dahulu!")
            elif bool(emailPenumpang2) == True:
                if noHpPenumpang2.isnumeric() == True:
                    if bool(tipePenumpang2) == True:
                        identitas2.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang2+"   /   "+tipePenumpang2, emailPenumpang2, noHpPenumpang2))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap pilih tipe penumpang terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi No. HP terlebih dahulu!")
            elif bool(noHpPenumpang2) == True:
                if bool(emailPenumpang2) == True:
                    if bool(tipePenumpang2) == True:
                        identitas2.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang2+"   /   "+tipePenumpang2, emailPenumpang2, noHpPenumpang2))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap pilih tipe penumpang terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi email terlebih dahulu!")
            elif bool(tipePenumpang2) == True:
                if bool(noHpPenumpang2) == True:
                    if bool(emailPenumpang2) == True:
                        identitas2.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang2+"   /   "+tipePenumpang2, emailPenumpang2, noHpPenumpang2))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap isi email terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi No. HP terlebih dahulu!")
            else:
                messagebox.showerror("Error!", "Harap isi identitas terlebih dahulu!")
        else:
            messagebox.showerror("Error!", "Harap isi identitas terlebih dahulu!")
            
    img = (Image.open("imgsrc\chair.png"))
    img_resize = img.resize((28,38), Image.LANCZOS)
    kursi = ImageTk.PhotoImage(img_resize)
    Label(isi, image=kursi, bg="#dfdfde").place(x=222, y=28)
    
    Label(isi, text="Penumpang 2", font=("vernada", 14), bg="#dfdfde").place(x=260, y=35)
    wrapper = CTkFrame(isi, width=480, height=350, fg_color="#f5f5f5", corner_radius=10)
    wrapper.place(x=220, y=75)
    
    nama_kereta = Label(wrapper, fg="#57a1f8", bg="#f5f5f5",font=("bold", 19), text="{}".format(namaKereta))
    nama_kereta.place(x=19, y=14)
    kelas_kereta = Label(wrapper,  fg="black", bg="#f5f5f5",font=("bold", 9), text="{}".format(kelasKereta))
    kelas_kereta.place(x=21, y=50)
    harga_kereta = Label(wrapper, fg="black", bg="#f5f5f5",font=("bold", 10), text="{}".format(hargaKereta))
    harga_kereta.place(x=394, y=23)
    
    Label(wrapper, text="Nama Lengkap", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=21, y=95)
    nama_user = Entry(wrapper, width=54, fg="#333333", border=0, bg="#f5f5f5", font=("Vernada", 11))
    nama_user.place(x=24, y=127)
    Frame(wrapper, width=430, height=1, bg="#999999").place(x=25, y=149)
    
    Label(wrapper, text="Email", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=21, y=163)
    email_user = Entry(wrapper, width=54, fg="#333333", border=0, bg="#f5f5f5", font=("Vernada", 11))
    email_user.place(x=24, y=195)
    Frame(wrapper, width=430, height=1, bg="#999999").place(x=25, y=217)
    
    Label(wrapper, text="No. Handphone", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=21, y=231)
    nohp_user = Entry(wrapper, width=27, fg="#333333", border=0, bg="#f5f5f5", font=("Vernada", 11))
    nohp_user.place(x=24, y=263)
    Frame(wrapper, width=205, height=1, bg="#999999").place(x=25, y=285)
    
    Label(wrapper, text="Tipe Penumpang", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=334, y=231)
    Frame(wrapper, width=100, height=1, bg="#999999").place(x=354, y=285)
    Tipe = ["Dewasa", "Pelajar"]
    tipe_penumpang = StringVar(isi)
    tipe_penumpang.set("")
    OptionMenu_tipe = OptionMenu(wrapper, tipe_penumpang, *Tipe)
    OptionMenu_tipe.configure(border=0, bg="#f5f5f5", width=8, cursor="hand2")
    OptionMenu_tipe.place(x=366, y=255)
    
    img = (Image.open("imgsrc\kembali.png"))
    img_resize = img.resize((23,23), Image.LANCZOS)
    button_img = ImageTk.PhotoImage(img_resize)
    CTkButton(isi, text="", image=button_img, width=0, height=0, cursor="hand2", fg_color="#dfdfde", hover_color="#dfdfde", command=transisi12).place(x=0, y=0)
    
    CTkButton(isi, width=481, height=30, text="Tambahkan", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=10, command=gantiButton2, cursor="hand2").place(x=220, y=435)
    system("cls")

    isi.mainloop()
    
def isiIdentitas3():
    global isi
    global nama_user
    isi = Toplevel()
    isi.geometry("920x500+170+80")
    isi.resizable(False, False)
    isi.configure(bg="#dfdfde")
    isi.title("K21 Railway Access")
    
    def gantiButton3():
        global namaPenumpang3
        global emailPenumpang3
        global noHpPenumpang3
        global tipePenumpang3
        namaPenumpang3 = nama_user.get()
        emailPenumpang3 = email_user.get()
        noHpPenumpang3 = nohp_user.get()
        tipePenumpang3 = tipe_penumpang.get()
        if bool(namaPenumpang3) == True:    
            if noHpPenumpang3.isnumeric() == True:
                if bool(emailPenumpang3) == True:
                    if bool(tipePenumpang3) == True:    
                        identitas3.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang3+"   /   "+tipePenumpang3, emailPenumpang3, noHpPenumpang3))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap pilih tipe penumpang terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi email terlebih dahulu!")
            elif bool(emailPenumpang3) == True:
                if noHpPenumpang3.isnumeric() == True:
                    if bool(tipePenumpang3) == True:
                        identitas3.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang3+"   /   "+tipePenumpang3, emailPenumpang3, noHpPenumpang3))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap pilih tipe penumpang terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi No. HP terlebih dahulu!")
            elif bool(noHpPenumpang3) == True:
                if bool(emailPenumpang3) == True:
                    if bool(tipePenumpang3) == True:
                        identitas3.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang3+"   /   "+tipePenumpang3, emailPenumpang3, noHpPenumpang3))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap pilih tipe penumpang terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi email terlebih dahulu!")
            elif bool(tipePenumpang3) == True:
                if bool(noHpPenumpang3) == True:
                    if bool(emailPenumpang3) == True:
                        identitas3.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang3+"   /   "+tipePenumpang3, emailPenumpang3, noHpPenumpang3))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap isi email terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi No. HP terlebih dahulu!")
            else:
                messagebox.showerror("Error!", "Harap isi identitas terlebih dahulu!")
        else:
            messagebox.showerror("Error!", "Harap isi identitas terlebih dahulu!")
            
    img = (Image.open("imgsrc\chair.png"))
    img_resize = img.resize((28,38), Image.LANCZOS)
    kursi = ImageTk.PhotoImage(img_resize)
    Label(isi, image=kursi, bg="#dfdfde").place(x=222, y=28)
    
    Label(isi, text="Penumpang 3", font=("vernada", 14), bg="#dfdfde").place(x=260, y=35)
    wrapper = CTkFrame(isi, width=480, height=350, fg_color="#f5f5f5", corner_radius=10)
    wrapper.place(x=220, y=75)
    
    nama_kereta = Label(wrapper, fg="#57a1f8", bg="#f5f5f5",font=("bold", 19), text="{}".format(namaKereta))
    nama_kereta.place(x=19, y=14)
    kelas_kereta = Label(wrapper,  fg="black", bg="#f5f5f5",font=("bold", 9), text="{}".format(kelasKereta))
    kelas_kereta.place(x=21, y=50)
    harga_kereta = Label(wrapper, fg="black", bg="#f5f5f5",font=("bold", 10), text="{}".format(hargaKereta))
    harga_kereta.place(x=394, y=23)
    
    Label(wrapper, text="Nama Lengkap", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=21, y=95)
    nama_user = Entry(wrapper, width=54, fg="#333333", border=0, bg="#f5f5f5", font=("Vernada", 11))
    nama_user.place(x=24, y=127)
    Frame(wrapper, width=430, height=1, bg="#999999").place(x=25, y=149)
    
    Label(wrapper, text="Email", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=21, y=163)
    email_user = Entry(wrapper, width=54, fg="#333333", border=0, bg="#f5f5f5", font=("Vernada", 11))
    email_user.place(x=24, y=195)
    Frame(wrapper, width=430, height=1, bg="#999999").place(x=25, y=217)
    
    Label(wrapper, text="No. Handphone", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=21, y=231)
    nohp_user = Entry(wrapper, width=27, fg="#333333", border=0, bg="#f5f5f5", font=("Vernada", 11))
    nohp_user.place(x=24, y=263)
    Frame(wrapper, width=205, height=1, bg="#999999").place(x=25, y=285)
    
    Label(wrapper, text="Tipe Penumpang", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=334, y=231)
    Frame(wrapper, width=100, height=1, bg="#999999").place(x=354, y=285)
    Tipe = ["Dewasa", "Pelajar"]
    tipe_penumpang = StringVar(isi)
    tipe_penumpang.set("")
    OptionMenu_tipe = OptionMenu(wrapper, tipe_penumpang, *Tipe)
    OptionMenu_tipe.configure(border=0, bg="#f5f5f5", width=8, cursor="hand2")
    OptionMenu_tipe.place(x=366, y=255)
    
    img = (Image.open("imgsrc\kembali.png"))
    img_resize = img.resize((23,23), Image.LANCZOS)
    button_img = ImageTk.PhotoImage(img_resize)
    CTkButton(isi, text="", image=button_img, width=0, height=0, cursor="hand2", fg_color="#dfdfde", hover_color="#dfdfde", command=transisi32).place(x=0, y=0)
    
    CTkButton(isi, width=481, height=30, text="Tambahkan", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=10, command=gantiButton3, cursor="hand2").place(x=220, y=435)
    system("cls")

    isi.mainloop()

def isiIdentitas4():
    global isi
    global nama_user
    isi = Toplevel()
    isi.geometry("920x500+170+80")
    isi.resizable(False, False)
    isi.configure(bg="#dfdfde")
    isi.title("K21 Railway Access")
    
    def gantiButton4():
        global namaPenumpang4
        global emailPenumpang4
        global noHpPenumpang4
        global tipePenumpang4
        namaPenumpang4 = nama_user.get()
        emailPenumpang4 = email_user.get()
        noHpPenumpang4 = nohp_user.get()
        tipePenumpang4 = tipe_penumpang.get()
        if bool(namaPenumpang4) == True:    
            if noHpPenumpang4.isnumeric() == True:
                if bool(emailPenumpang4) == True:
                    if bool(tipePenumpang4) == True:    
                        identitas4.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang4+"   /   "+tipePenumpang4, emailPenumpang4, noHpPenumpang4))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap pilih tipe penumpang terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi email terlebih dahulu!")
            elif bool(emailPenumpang4) == True:
                if noHpPenumpang4.isnumeric() == True:
                    if bool(tipePenumpang4) == True:
                        identitas4.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang4+"   /   "+tipePenumpang4, emailPenumpang4, noHpPenumpang4))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap pilih tipe penumpang terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi No. HP terlebih dahulu!")
            elif bool(noHpPenumpang4) == True:
                if bool(emailPenumpang4) == True:
                    if bool(tipePenumpang4) == True:
                        identitas4.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang4+"   /   "+tipePenumpang4, emailPenumpang4, noHpPenumpang4))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap pilih tipe penumpang terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi email terlebih dahulu!")
            elif bool(tipePenumpang4) == True:
                if bool(noHpPenumpang4) == True:
                    if bool(emailPenumpang4) == True:
                        identitas4.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang4+"   /   "+tipePenumpang4, emailPenumpang4, noHpPenumpang4))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap isi email terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi No. HP terlebih dahulu!")
            else:
                messagebox.showerror("Error!", "Harap isi identitas terlebih dahulu!")
        else:
            messagebox.showerror("Error!", "Harap isi identitas terlebih dahulu!")
            
    img = (Image.open("imgsrc\chair.png"))
    img_resize = img.resize((28,38), Image.LANCZOS)
    kursi = ImageTk.PhotoImage(img_resize)
    Label(isi, image=kursi, bg="#dfdfde").place(x=222, y=28)
    
    Label(isi, text="Penumpang 4", font=("vernada", 14), bg="#dfdfde").place(x=260, y=35)
    wrapper = CTkFrame(isi, width=480, height=350, fg_color="#f5f5f5", corner_radius=10)
    wrapper.place(x=220, y=75)
    
    nama_kereta = Label(wrapper, fg="#57a1f8", bg="#f5f5f5",font=("bold", 19), text="{}".format(namaKereta))
    nama_kereta.place(x=19, y=14)
    kelas_kereta = Label(wrapper,  fg="black", bg="#f5f5f5",font=("bold", 9), text="{}".format(kelasKereta))
    kelas_kereta.place(x=21, y=50)
    harga_kereta = Label(wrapper, fg="black", bg="#f5f5f5",font=("bold", 10), text="{}".format(hargaKereta))
    harga_kereta.place(x=394, y=23)
    
    Label(wrapper, text="Nama Lengkap", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=21, y=95)
    nama_user = Entry(wrapper, width=54, fg="#333333", border=0, bg="#f5f5f5", font=("Vernada", 11))
    nama_user.place(x=24, y=127)
    Frame(wrapper, width=430, height=1, bg="#999999").place(x=25, y=149)
    
    Label(wrapper, text="Email", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=21, y=163)
    email_user = Entry(wrapper, width=54, fg="#333333", border=0, bg="#f5f5f5", font=("Vernada", 11))
    email_user.place(x=24, y=195)
    Frame(wrapper, width=430, height=1, bg="#999999").place(x=25, y=217)
    
    Label(wrapper, text="No. Handphone", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=21, y=231)
    nohp_user = Entry(wrapper, width=27, fg="#333333", border=0, bg="#f5f5f5", font=("Vernada", 11))
    nohp_user.place(x=24, y=263)
    Frame(wrapper, width=205, height=1, bg="#999999").place(x=25, y=285)
    
    Label(wrapper, text="Tipe Penumpang", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=334, y=231)
    Frame(wrapper, width=100, height=1, bg="#999999").place(x=354, y=285)
    Tipe = ["Dewasa", "Pelajar"]
    tipe_penumpang = StringVar(isi)
    tipe_penumpang.set("")
    OptionMenu_tipe = OptionMenu(wrapper, tipe_penumpang, *Tipe)
    OptionMenu_tipe.configure(border=0, bg="#f5f5f5", width=8, cursor="hand2")
    OptionMenu_tipe.place(x=366, y=255)
    
    img = (Image.open("imgsrc\kembali.png"))
    img_resize = img.resize((23,23), Image.LANCZOS)
    button_img = ImageTk.PhotoImage(img_resize)
    CTkButton(isi, text="", image=button_img, width=0, height=0, cursor="hand2", fg_color="#dfdfde", hover_color="#dfdfde", command=transisi42).place(x=0, y=0)
    
    CTkButton(isi, width=481, height=30, text="Tambahkan", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=10, command=gantiButton4, cursor="hand2").place(x=220, y=435)
    system("cls")

    isi.mainloop()
    
def isiIdentitas5():
    global isi
    global nama_user
    isi = Toplevel()
    isi.geometry("920x500+170+80")
    isi.resizable(False, False)
    isi.configure(bg="#dfdfde")
    isi.title("K21 Railway Access")
    
    def gantiButton5():
        global namaPenumpang5
        global emailPenumpang5
        global noHpPenumpang5
        global tipePenumpang5
        namaPenumpang5 = nama_user.get()
        emailPenumpang5 = email_user.get()
        noHpPenumpang5 = nohp_user.get()
        tipePenumpang5 = tipe_penumpang.get()
        if bool(namaPenumpang5) == True:    
            if noHpPenumpang5.isnumeric() == True:
                if bool(emailPenumpang5) == True:
                    if bool(tipePenumpang5) == True:    
                        identitas5.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang5+"   /   "+tipePenumpang5, emailPenumpang5, noHpPenumpang5))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap pilih tipe penumpang terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi email terlebih dahulu!")
            elif bool(emailPenumpang5) == True:
                if noHpPenumpang5.isnumeric() == True:
                    if bool(tipePenumpang5) == True:
                        identitas5.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang5+"   /   "+tipePenumpang5, emailPenumpang5, noHpPenumpang5))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap pilih tipe penumpang terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi No. HP terlebih dahulu!")
            elif bool(noHpPenumpang5) == True:
                if bool(emailPenumpang5) == True:
                    if bool(tipePenumpang5) == True:
                        identitas5.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang5+"   /   "+tipePenumpang5, emailPenumpang5, noHpPenumpang5))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap pilih tipe penumpang terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi email terlebih dahulu!")
            elif bool(tipePenumpang5) == True:
                if bool(noHpPenumpang5) == True:
                    if bool(emailPenumpang5) == True:
                        identitas5.configure(text="{}\n\n{}\n\n{}".format(namaPenumpang5+"   /   "+tipePenumpang5, emailPenumpang5, noHpPenumpang5))
                        isi.destroy()
                        iden.after(1000)
                        iden.deiconify()
                    else:
                        messagebox.showinfo("Error!", "Harap isi email terlebih dahulu!")
                else:
                    messagebox.showinfo("Error!", "Harap isi No. HP terlebih dahulu!")
            else:
                messagebox.showerror("Error!", "Harap isi identitas terlebih dahulu!")
        else:
            messagebox.showerror("Error!", "Harap isi identitas terlebih dahulu!")
            
    img = (Image.open("imgsrc\chair.png"))
    img_resize = img.resize((28,38), Image.LANCZOS)
    kursi = ImageTk.PhotoImage(img_resize)
    Label(isi, image=kursi, bg="#dfdfde").place(x=222, y=28)
    
    Label(isi, text="Penumpang 5", font=("vernada", 14), bg="#dfdfde").place(x=260, y=35)
    wrapper = CTkFrame(isi, width=480, height=350, fg_color="#f5f5f5", corner_radius=10)
    wrapper.place(x=220, y=75)
    
    nama_kereta = Label(wrapper, fg="#57a1f8", bg="#f5f5f5",font=("bold", 19), text="{}".format(namaKereta))
    nama_kereta.place(x=19, y=14)
    kelas_kereta = Label(wrapper,  fg="black", bg="#f5f5f5",font=("bold", 9), text="{}".format(kelasKereta))
    kelas_kereta.place(x=21, y=50)
    harga_kereta = Label(wrapper, fg="black", bg="#f5f5f5",font=("bold", 10), text="{}".format(hargaKereta))
    harga_kereta.place(x=394, y=23)
    
    Label(wrapper, text="Nama Lengkap", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=21, y=95)
    nama_user = Entry(wrapper, width=54, fg="#333333", border=0, bg="#f5f5f5", font=("Vernada", 11))
    nama_user.place(x=24, y=127)
    Frame(wrapper, width=430, height=1, bg="#999999").place(x=25, y=149)
    
    Label(wrapper, text="Email", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=21, y=163)
    email_user = Entry(wrapper, width=54, fg="#333333", border=0, bg="#f5f5f5", font=("Vernada", 11))
    email_user.place(x=24, y=195)
    Frame(wrapper, width=430, height=1, bg="#999999").place(x=25, y=217)
    
    Label(wrapper, text="No. Handphone", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=21, y=231)
    nohp_user = Entry(wrapper, width=27, fg="#333333", border=0, bg="#f5f5f5", font=("Vernada", 11))
    nohp_user.place(x=24, y=263)
    Frame(wrapper, width=205, height=1, bg="#999999").place(x=25, y=285)
    
    Label(wrapper, text="Tipe Penumpang", fg="black", bg="#f5f5f5", font=("Vernada", 12)).place(x=334, y=231)
    Frame(wrapper, width=100, height=1, bg="#999999").place(x=354, y=285)
    Tipe = ["Dewasa", "Pelajar"]
    tipe_penumpang = StringVar(isi)
    tipe_penumpang.set("")
    OptionMenu_tipe = OptionMenu(wrapper, tipe_penumpang, *Tipe)
    OptionMenu_tipe.configure(border=0, bg="#f5f5f5", width=8, cursor="hand2")
    OptionMenu_tipe.place(x=366, y=255)
    
    img = (Image.open("imgsrc\kembali.png"))
    img_resize = img.resize((23,23), Image.LANCZOS)
    button_img = ImageTk.PhotoImage(img_resize)
    CTkButton(isi, text="", image=button_img, width=0, height=0, cursor="hand2", fg_color="#dfdfde", hover_color="#dfdfde", command=transisi52).place(x=0, y=0)
    
    CTkButton(isi, width=481, height=30, text="Tambahkan", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=10, command=gantiButton5, cursor="hand2").place(x=220, y=435)
    system("cls")

    isi.mainloop()    
    
def penumpangSatu():
    global iden
    global identitas1
    iden = Toplevel()
    iden.geometry("920x500+170+80")
    iden.resizable(False, False)
    iden.configure(bg="#fff")
    iden.title("K21 Railway Access")
    
    def identitasUser():
        if bool(namaPenumpang1) == False:
            messagebox.showinfo("Error!", "Harap isi identitas penumpang terlebih dahulu!")
        else:
            iden.withdraw()
            paymentPage()
    
    wrapper = LabelFrame(iden)
    wrapper.pack(side=BOTTOM, fill=BOTH, expand=YES, pady=47, padx=250)

    mycanvas = Canvas(wrapper, bg="#dde6de")
    mycanvas.pack(fill=BOTH, expand="yes")
    
    identitas1 = CTkButton(mycanvas, text="Penumpang 1", width=490, height=130, cursor="hand2", fg_color="white", hover_color="#efefef", text_color="black", command=transisi1)
    identitas1.pack(expand=TRUE, padx=5)
    
    heading = Frame(iden, width=920, height=45, bg="#57a1f8")
    heading.place(x=0, y=0)
    
    img = (Image.open("imgsrc\kembali.png"))
    img_resize = img.resize((23,23), Image.ANTIALIAS)
    button_img = ImageTk.PhotoImage(img_resize)
    heading_text = Label(heading, bg="#57a1f8", fg="black", text=f"List Penumpang", font=("Microsoft YaHei UI Heavy", 12))
    heading_text.place(x=386, y=9)
    CTkButton(heading, text="", image=button_img, width=0, height=0, cursor="hand2", fg_color="#57a1f8", hover_color="#57a1f8", command=transisiSchedulIdentity).place(x=0, y=6)
    CTkButton(iden, width=424, height=30, text="Lanjut Pembayaran", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=10, cursor="hand2", command=identitasUser).place(x=247, y=457)
    system("cls")

    iden.mainloop()

def penumpangDua():
    global iden
    global identitas1
    global identitas2
    iden = Toplevel()
    iden.geometry("920x500+170+80")
    iden.resizable(False, False)
    iden.configure(bg="#fff")
    iden.title("K21 Railway Access")
    wrapper = LabelFrame(iden)
    wrapper.pack(side=BOTTOM, fill=BOTH, expand=YES, pady=47, padx=250)
    def identitasUser():
        if bool(namaPenumpang1) == False or bool(namaPenumpang2) == False:
            messagebox.showinfo("Error!", "Harap isi identitas penumpang terlebih dahulu!")
        else:
            iden.withdraw()
            paymentPage()
    
    heading = Frame(iden, width=920, height=45, bg="#57a1f8")
    heading.place(x=0, y=0)
    
    img = (Image.open("imgsrc\kembali.png"))
    img_resize = img.resize((23,23), Image.ANTIALIAS)
    button_img = ImageTk.PhotoImage(img_resize)
    heading_text = Label(heading, bg="#57a1f8", fg="black", text=f"List Penumpang", font=("Microsoft YaHei UI Heavy", 12))
    heading_text.place(x=386, y=9)
    CTkButton(heading, text="", image=button_img, width=0, height=0, cursor="hand2", fg_color="#57a1f8", hover_color="#57a1f8", command=transisiSchedulIdentity).place(x=0, y=6)

    mycanvas = Canvas(wrapper, bg="#dde6de")
    mycanvas.pack(fill=BOTH, expand="yes")
    
    identitas1 = CTkButton(mycanvas, text="Penumpang 1", width=490, height=130, cursor="hand2", fg_color="white", hover_color="#efefef", text_color="black", command=transisi1)
    identitas1.pack(expand=TRUE, padx=5)
    identitas2 = CTkButton(mycanvas, text="Penumpang 2", width=490, height=130, cursor="hand2", fg_color="white", hover_color="#efefef", text_color="black", command=transisi2)
    identitas2.pack(expand=TRUE, padx=5)
        
    CTkButton(iden, width=424, height=30, text="Lanjut Pembayaran", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=10, cursor="hand2", command=identitasUser).place(x=247, y=457)
    system("cls")
    
    iden.mainloop()
    
def penumpangTiga():
    global iden
    global identitas1
    global identitas2
    global identitas3
    iden = Toplevel()
    iden.geometry("920x500+170+80")
    iden.resizable(False, False)
    iden.configure(bg="#fff")
    iden.title("K21 Railway Access")
    wrapper = LabelFrame(iden)
    wrapper.pack(side=BOTTOM, fill=BOTH, expand=YES, pady=47, padx=250)

    def identitasUser():
        if bool(namaPenumpang1) == False or bool(namaPenumpang2) == False or bool(namaPenumpang3) == False:
            messagebox.showinfo("Error!", "Harap isi identitas penumpang terlebih dahulu!")
        else:
            iden.withdraw()
            paymentPage()
            
    heading = Frame(iden, width=920, height=45, bg="#57a1f8")
    heading.place(x=0, y=0)
    
    img = (Image.open("imgsrc\kembali.png"))
    img_resize = img.resize((23,23), Image.ANTIALIAS)
    button_img = ImageTk.PhotoImage(img_resize)
    heading_text = Label(heading, bg="#57a1f8", fg="black", text=f"List Penumpang", font=("Microsoft YaHei UI Heavy", 12))
    heading_text.place(x=386, y=9)
    CTkButton(heading, text="", image=button_img, width=0, height=0, cursor="hand2", fg_color="#57a1f8", hover_color="#57a1f8", command=transisiSchedulIdentity).place(x=0, y=6)

    mycanvas = Canvas(wrapper, bg="#dde6de")
    mycanvas.pack(fill=BOTH, expand="yes")
    
    myframe = Frame(mycanvas, bg="#dde6de")
    mycanvas.create_window((0,0), window=myframe, anchor="nw")
    
    identitas1 = CTkButton(mycanvas, text="Penumpang 1", width=400, height=130, cursor="hand2", fg_color="white", corner_radius=8, hover_color="#efefef", text_color="black", command=transisi1)
    identitas1.pack(expand=TRUE, pady=6, padx=2)
    identitas2 = CTkButton(mycanvas, text="Penumpang 2", width=400, height=130, cursor="hand2", fg_color="white", corner_radius=8, hover_color="#efefef", text_color="black", command=transisi2)
    identitas2.pack(expand=TRUE, pady=6, padx=2)
    identitas3 = CTkButton(mycanvas, text="Penumpang 3", width=400, height=130, cursor="hand2", fg_color="white", corner_radius=8, hover_color="#efefef", text_color="black", command=transisi3)
    identitas3.pack(expand=TRUE, pady=6, padx=2)
    
    CTkButton(iden, width=424, height=30, text="Lanjut Pembayaran", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=10, cursor="hand2", command=identitasUser).place(x=247, y=457)
    system("cls")
    
    iden.mainloop()
    
def penumpangEmpat():
    global iden
    global identitas1
    global identitas2
    global identitas3
    global identitas4
    iden = Toplevel()
    iden.geometry("920x500+170+80")
    iden.resizable(False, False)
    iden.configure(bg="#fff")
    iden.title("K21 Railway Access")
    wrapper = LabelFrame(iden)
    wrapper.pack(side=BOTTOM, fill=BOTH, expand=YES, pady=47, padx=250)
    style = ttk.Style()
    style.theme_use('default')
    style.configure("Vertical.TScrollbar", background="#57a1f8", bordercolor="#000000", arrowcolor="#fff", troughcolor="white")
    def identitasUser():
        if bool(namaPenumpang1) == False or bool(namaPenumpang2) == False or bool(namaPenumpang3) == False or bool(namaPenumpang4) == False:
            messagebox.showinfo("Error!", "Harap isi identitas penumpang terlebih dahulu!")
        else:
            iden.withdraw()
            paymentPage()
    
    heading = Frame(iden, width=920, height=45, bg="#57a1f8")
    heading.place(x=0, y=0)
    
    img = (Image.open("imgsrc\kembali.png"))
    img_resize = img.resize((23,23), Image.ANTIALIAS)
    button_img = ImageTk.PhotoImage(img_resize)
    heading_text = Label(heading, bg="#57a1f8", fg="black", text=f"List Penumpang", font=("Microsoft YaHei UI Heavy", 12))
    heading_text.place(x=386, y=9)
    CTkButton(heading, text="", image=button_img, width=0, height=0, cursor="hand2", fg_color="#57a1f8", hover_color="#57a1f8", command=transisiSchedulIdentity).place(x=0, y=6)

    mycanvas = Canvas(wrapper, bg="#dde6de")
    mycanvas.pack(side=LEFT, fill=BOTH, expand="yes")

    yscrollbar = ttk.Scrollbar(wrapper, orient=VERTICAL, command=mycanvas.yview)
    yscrollbar.pack(side=RIGHT, fill=Y)

    mycanvas.configure(yscrollcommand=yscrollbar.set)
    mycanvas.bind("<Configure>", lambda e: mycanvas.configure(scrollregion = mycanvas.bbox("all")))

    myframe = CTkFrame(mycanvas, fg_color="#dde6de", corner_radius=10)
    mycanvas.create_window((0,0), window=myframe, anchor="nw")
    
    identitas1 = CTkButton(myframe, text="Penumpang 1", width=385, height=130, cursor="hand2", fg_color="white", corner_radius=8, hover_color="#efefef", text_color="black", command=transisi1)
    identitas1.pack(expand=TRUE, pady=4,padx=5)
    identitas2 = CTkButton(myframe, text="Penumpang 2", width=385, height=130, cursor="hand2", fg_color="white", corner_radius=8, hover_color="#efefef", text_color="black", command=transisi2)
    identitas2.pack(expand=TRUE, pady=4,padx=5)
    identitas3 = CTkButton(myframe, text="Penumpang 3", width=385, height=130, cursor="hand2", fg_color="white", corner_radius=8, hover_color="#efefef", text_color="black", command=transisi3)
    identitas3.pack(expand=TRUE, pady=4,padx=5)
    identitas4 = CTkButton(myframe, text="Penumpang 4", width=385, height=130, cursor="hand2", fg_color="white", corner_radius=8, hover_color="#efefef", text_color="black", command=transisi4)
    identitas4.pack(expand=TRUE, pady=4,padx=5)
        
    CTkButton(iden, width=424, height=30, text="Lanjut Pembayaran", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=10, cursor="hand2", command=identitasUser).place(x=247, y=457)
    system("cls")

    iden.mainloop()
    
def penumpangLima():
    global iden
    global identitas1
    global identitas2
    global identitas3
    global identitas4
    global identitas5
    iden = Toplevel()
    iden.geometry("920x500+170+80")
    iden.resizable(False, False)
    iden.configure(bg="#fff")
    iden.title("K21 Railway Access")
    wrapper = LabelFrame(iden)
    wrapper.pack(side=BOTTOM, fill=BOTH, expand=YES, pady=47, padx=250)
    style = ttk.Style()
    style.theme_use('default')
    style.configure("Vertical.TScrollbar", background="#57a1f8", bordercolor="#000000", arrowcolor="#fff", troughcolor="white")
    
    def identitasUser():
        if bool(namaPenumpang1) == False or bool(namaPenumpang2) == False or bool(namaPenumpang3) == False or bool(namaPenumpang4) == False or bool(namaPenumpang4) == False:
            messagebox.showinfo("Error!", "Harap isi identitas penumpang terlebih dahulu!")
        else:
            iden.withdraw()
            paymentPage()
            
    heading = Frame(iden, width=920, height=45, bg="#57a1f8")
    heading.place(x=0, y=0)
    
    img = (Image.open("imgsrc\kembali.png"))
    img_resize = img.resize((23,23), Image.ANTIALIAS)
    button_img = ImageTk.PhotoImage(img_resize)
    heading_text = Label(heading, bg="#57a1f8", fg="black", text=f"List Penumpang", font=("Microsoft YaHei UI Heavy", 12))
    heading_text.place(x=386, y=9)
    CTkButton(heading, text="", image=button_img, width=0, height=0, cursor="hand2", fg_color="#57a1f8", hover_color="#57a1f8", command=transisiSchedulIdentity).place(x=0, y=6)

    mycanvas = Canvas(wrapper, bg="#dde6de")
    mycanvas.pack(side=LEFT, fill=BOTH, expand="yes")

    yscrollbar = ttk.Scrollbar(wrapper, orient=VERTICAL, command=mycanvas.yview)
    yscrollbar.pack(side=RIGHT, fill=Y)

    mycanvas.configure(yscrollcommand=yscrollbar.set)
    mycanvas.bind("<Configure>", lambda e: mycanvas.configure(scrollregion = mycanvas.bbox("all")))

    myframe = Frame(mycanvas, bg="#dde6de")
    mycanvas.create_window((0,0), window=myframe, anchor="nw")

    identitas1 = CTkButton(myframe, text="Penumpang 1", width=385, height=130, cursor="hand2", fg_color="white", corner_radius=8, hover_color="#efefef", text_color="black", command=transisi1)
    identitas1.pack(expand=TRUE, pady=4,padx=5)
    identitas2 = CTkButton(myframe, text="Penumpang 2", width=385, height=130, cursor="hand2", fg_color="white", corner_radius=8, hover_color="#efefef", text_color="black", command=transisi2)
    identitas2.pack(expand=TRUE, pady=4,padx=5)
    identitas3 = CTkButton(myframe, text="Penumpang 3", width=385, height=130, cursor="hand2", fg_color="white", corner_radius=8, hover_color="#efefef", text_color="black", command=transisi3)
    identitas3.pack(expand=TRUE, pady=4,padx=5)
    identitas4 = CTkButton(myframe, text="Penumpang 4", width=385, height=130, cursor="hand2", fg_color="white", corner_radius=8, hover_color="#efefef", text_color="black", command=transisi4)
    identitas4.pack(expand=TRUE, pady=4,padx=5)
    identitas5 = CTkButton(myframe, text="Penumpang 5", width=385, height=130, cursor="hand2", fg_color="white", corner_radius=8, hover_color="#efefef", text_color="black", command=transisi5)
    identitas5.pack(expand=TRUE, pady=4,padx=5)
        
    CTkButton(iden, width=424, height=30, text="Lanjut Pembayaran", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=10, cursor="hand2", command=identitasUser).place(x=247, y=457)
    system("cls")
   
    iden.mainloop()

def transisiPaymentBack():
    if jumlahPenumpang == 1:
        payment.destroy()
        iden.after(600)
        iden.deiconify()
    elif jumlahPenumpang == 2:
        payment.destroy()
        iden.after(600)
        iden.deiconify()
    elif jumlahPenumpang == 3:
        payment.destroy()
        iden.after(600)
        iden.deiconify()
    elif jumlahPenumpang == 4:
        payment.destroy()
        iden.after(600)
        iden.deiconify()
    else:
        payment.destroy()
        iden.after(600)
        iden.deiconify()

def id_generator(size=6, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))

def paymentPage(): 
    global payment
    global bayar
    def addHistory():
        kode = []
        def Addjson(new_data, filename='purchase.history.json'):
            with open(filename,'r+') as file:
                file_data = json.load(file)
                file_data[Username].append(new_data)
                file.seek(0)
                json.dump(file_data, file, indent = 4)
        if jumlahPenumpang == 1:
            namaHistory = [namaPenumpang1]
            emailHistory = [emailPenumpang1]
            noHPHistory = [noHpPenumpang1]
            for i in range (0, jumlahPenumpang):
                code = id_generator()
                kode.append(code)
                y = {
                    "Kode": f"{kode[i]}",
                    "Nama Lengkap": f"{namaHistory[i]}",
                    "Email": f"{emailHistory[i]}",
                    "No. HP": f"{noHPHistory[i]}",
                    "Kereta": f"{namaKereta}",
                    "Kelas": f"{kelasKereta}",
                    "Harga": f"{hargaKereta}",
                    "Kota Asal": f"{userAsal}",
                    "Kota Tujuan": f"{userTujuan}",
                    "Waktu Berangkat": f"{waktuBerangkat}",
                    "Waktu Sampai": f"{waktuSampai}",
                    "Tanggal Pesan": f"{tgl_banding}",
                }
                Addjson(y)
        elif jumlahPenumpang == 2:
            namaHistory = [namaPenumpang1, namaPenumpang2]
            emailHistory = [emailPenumpang1, emailPenumpang2]
            noHPHistory = [noHpPenumpang1, noHpPenumpang2]
            for i in range (0, jumlahPenumpang):
                code = id_generator()
                kode.append(code)
                y = {
                    "Kode": f"{kode[i]}",
                    "Nama Lengkap": f"{namaHistory[i]}",
                    "Email": f"{emailHistory[i]}",
                    "No. HP": f"{noHPHistory[i]}",
                    "Kereta": f"{namaKereta}",
                    "Kelas": f"{kelasKereta}",
                    "Harga": f"{hargaKereta}",
                    "Kota Asal": f"{userAsal}",
                    "Kota Tujuan": f"{userTujuan}",
                    "Waktu Berangkat": f"{waktuBerangkat}",
                    "Waktu Sampai": f"{waktuSampai}",
                    "Tanggal Pesan": f"{tgl_banding}",
                }
                Addjson(y)
        elif jumlahPenumpang == 3:
            namaHistory = [namaPenumpang1, namaPenumpang2, namaPenumpang3]
            emailHistory = [emailPenumpang1, emailPenumpang2, emailPenumpang3]
            noHPHistory = [noHpPenumpang1, noHpPenumpang2, noHpPenumpang3]
            for i in range (0, jumlahPenumpang):
                code = id_generator()
                kode.append(code)
                y = {
                    "Kode": f"{kode[i]}",
                    "Nama Lengkap": f"{namaHistory[i]}",
                    "Email": f"{emailHistory[i]}",
                    "No. HP": f"{noHPHistory[i]}",
                    "Kereta": f"{namaKereta}",
                    "Kelas": f"{kelasKereta}",
                    "Harga": f"{hargaKereta}",
                    "Kota Asal": f"{userAsal}",
                    "Kota Tujuan": f"{userTujuan}",
                    "Waktu Berangkat": f"{waktuBerangkat}",
                    "Waktu Sampai": f"{waktuSampai}",
                    "Tanggal Pesan": f"{tgl_banding}",
                }
                Addjson(y)
        elif jumlahPenumpang == 4:
            namaHistory = [namaPenumpang1, namaPenumpang2, namaPenumpang3, namaPenumpang4]
            emailHistory = [emailPenumpang1, emailPenumpang2, emailPenumpang3, emailPenumpang4]
            noHPHistory = [noHpPenumpang1, noHpPenumpang2, noHpPenumpang3, noHpPenumpang4]
            for i in range (0, jumlahPenumpang):
                code = id_generator()
                kode.append(code)
                y = {
                    "Kode": f"{kode[i]}",
                    "Nama Lengkap": f"{namaHistory[i]}",
                    "Email": f"{emailHistory[i]}",
                    "No. HP": f"{noHPHistory[i]}",
                    "Kereta": f"{namaKereta}",
                    "Kelas": f"{kelasKereta}",
                    "Harga": f"{hargaKereta}",
                    "Kota Asal": f"{userAsal}",
                    "Kota Tujuan": f"{userTujuan}",
                    "Waktu Berangkat": f"{waktuBerangkat}",
                    "Waktu Sampai": f"{waktuSampai}",
                    "Tanggal Pesan": f"{tgl_banding}",
                }
                Addjson(y)
        else:
            namaHistory = [namaPenumpang1, namaPenumpang2, namaPenumpang3, namaPenumpang4, namaPenumpang5]
            emailHistory = [emailPenumpang1, emailPenumpang2, emailPenumpang3, emailPenumpang4, emailPenumpang5]
            noHPHistory = [noHpPenumpang1, noHpPenumpang2, noHpPenumpang3, noHpPenumpang4, noHpPenumpang5]
            for i in range (0, jumlahPenumpang):
                code = id_generator()
                kode.append(code)
                y = {
                    "Kode": f"{kode[i]}",
                    "Nama Lengkap": f"{namaHistory[i]}",
                    "Email": f"{emailHistory[i]}",
                    "No. HP": f"{noHPHistory[i]}",
                    "Kereta": f"{namaKereta}",
                    "Kelas": f"{kelasKereta}",
                    "Harga": f"{hargaKereta}",
                    "Kota Asal": f"{userAsal}",
                    "Kota Tujuan": f"{userTujuan}",
                    "Waktu Berangkat": f"{waktuBerangkat}",
                    "Waktu Sampai": f"{waktuSampai}",
                    "Tanggal Pesan": f"{tgl_banding}",
                }
                Addjson(y)
                
    def tanggalTiket():
        hari = tgl_banding.strftime("%a")
        tanggal = tgl_banding.strftime("%d")
        bulan = tgl_banding.strftime("%b")
        tahun = tgl_banding.strftime("%y")
        x = f"{hari}, {tanggal} {bulan} {tahun}"
        return x
    def hitungDurasi(): 
        from datetime import datetime
        durasi = datetime.strptime(waktuSampai, "%H:%M") - datetime.strptime(waktuBerangkat, "%H:%M")
        durasiTampil = "{}j {}m".format(((datetime.strptime(str(durasi), "%H:%M:%S")).strftime("%H")).replace("0", ""), ((datetime.strptime(str(durasi), "%H:%M:%S")).strftime("%M")).replace("0", ""))
        return durasiTampil
    def inisialKelas():
        kelas = kelasKereta[0:3].upper()
        return kelas
    def hitungHarga():
        global nominalBayar
        def split(word):
            return list(word)
        nominal = int("".join(hargaKereta[2:].split(".")))
        nominalBayar = jumlahPenumpang * nominal
        if len(str(nominalBayar)) == 7:
            gantiRp = split(str(nominalBayar))
            gantiRp.insert(1, ".")
            gantiRp.insert(5, ".")
            nominalTampil = "Rp{}".format("".join(gantiRp))
        elif len(str(nominalBayar)) == 6:
            gantiRp = split(str(nominalBayar))
            gantiRp.insert(3, ".")
            nominalTampil = "Rp{}".format("".join(gantiRp))
        else:
            gantiRp = split(str(nominalBayar))
            gantiRp.insert(2, ".")
            nominalTampil = "Rp{}".format("".join(gantiRp))
        return nominalTampil
    def pembayaran():
        payment.withdraw()
        def bayarBack():
            bayar.destroy()
            payment.after(700)
            payment.deiconify()
        def ya():
            addHistory()
            schedul.destroy()
            iden.destroy()
            bayar.destroy()
            payment.destroy()
            confirm.destroy()
            messagebox.showinfo("Success!", "Pembayaran berhasil!")
            Asal.set("")
            Tujuan.set("")
            Tanggal_pilih.configure(text="")
            banyakPenumpang.set("")
            main.after(600)
            main.deiconify()
        def tidak():
            confirm.destroy()
            bayar.after(400)
            bayar.deiconify()
        def cekUserBayar():
            global confirm
            isiBayar = userBayar.get()
            if isiBayar == "":
                messagebox.showerror("Error!", "Harap diisi terlebih dahulu!")
            elif (isiBayar.isnumeric()) == True:
                bandingNominal = int(isiBayar)
                if bandingNominal < nominalBayar:
                    messagebox.showerror("Error!", "Nominal yang Anda masukkan kurang!")
                elif bandingNominal == nominalBayar:
                    addHistory()
                    schedul.destroy()
                    iden.destroy()
                    bayar.destroy()
                    payment.destroy()
                    messagebox.showinfo("Success!", "Pembayaran berhasil!")
                    Asal.set("")
                    Tujuan.set("")
                    Tanggal_pilih.configure(text="")
                    banyakPenumpang.set("")
                    main.after(600)
                    main.deiconify()
                else:
                    bayar.withdraw()
                    confirm = Toplevel()
                    confirm.geometry("200x100+550+270")
                    confirm.resizable(False, False)
                    Label(confirm, text="Nominal yang Anda masukkan lebih\ndari tagihan\nApakah lanjut?").place(x=2, y=10)
                    CTkButton(confirm, width=47, height=28, text="Ya", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=7, cursor="hand2", command=ya).place(x=35, y=62)
                    CTkButton(confirm, width=40, height=28, text="Tidak", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=7, cursor="hand2", command=tidak).place(x=120, y=62)
                    confirm.mainloop()
            else:
                messagebox.showerror("Error!", "Nominal haruslah angka!")
                
        bayar = Toplevel()
        bayar.geometry("250x100+520+270")
        bayar.title("K21 Railway Access")
        bayar.configure(bg="#dfdfde")
        Label(bayar, text="Masukkan nominal yang dibayarkan:", bg="#dfdfde").place(x=25, y=15)
        userBayar = Entry(bayar, width=25, font=("Calibri", 11))
        userBayar.place(x=35, y=40)
        CTkButton(bayar, text="", image=button_img, width=0, height=0, cursor="hand2", fg_color="#dfdfde", bg_color="#dfdfde", border_spacing=0, hover_color="#dfdfde", command=bayarBack).place(x=0, y=0)
        
        CTkButton(bayar, width=65, height=28, text="Bayar", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=7, cursor="hand2", command=cekUserBayar).place(x=95, y=68)

        bayar.mainloop()

    payment = Toplevel()
    payment.geometry("920x500+170+80")
    payment.resizable(False, False)
    payment.configure(bg="#dfdfde")
    payment.title("K21 Railway Access")

    Frame(payment, width=920, height=30, bg="#57a1f8").place(x=0, y=0)
    img = (Image.open("imgsrc\kembali.png"))
    img_resize = img.resize((23,23), Image.LANCZOS)
    button_img = ImageTk.PhotoImage(img_resize)
    CTkButton(payment, text="", image=button_img, width=0, height=0, cursor="hand2", fg_color="#57a1f8", bg_color="#57a1f8", border_spacing=0, hover_color="#57a1f8", command=transisiPaymentBack).place(x=0, y=0)

    img = (Image.open("imgsrc\ekanan.png"))
    img_resize = img.resize((10,20), Image.LANCZOS)
    kanan_img = ImageTk.PhotoImage(img_resize)

    wrapper1 = CTkFrame(payment, width=400, height=200, fg_color="#f5f5f5", corner_radius=10)
    wrapper1.place(x=262, y=42)

    Label(wrapper1, text="{}".format(namaKereta), fg="#2F58CD", bg="#f5f5f5", font=("Calibri", 22)).place(x=14, y=7)
    Frame(wrapper1, width=360, height=1, bg="#999999").place(x=20, y=53)

    Label(wrapper1, text="{}\n                      ".format(userAsal), fg="#444444", bg="#f5f5f5", font=("Calibri", 11),justify="left").place(x=22, y=57)
    Label(wrapper1, text="{}\n                              ".format(userTujuan), fg="#444444", bg="#f5f5f5", font=("Calibri", 11), justify="right").place(x=282, y=57)
    Label(wrapper1, text="{}".format(waktuBerangkat), fg="#205295", bg="#f5f5f5", font=("Microsoft YaHei UI Light", 26)).place(x=21, y=93)
    Label(wrapper1, text="{}\n          ".format(waktuSampai), fg="#205295", bg="#f5f5f5", font=("Microsoft YaHei UI Light", 26), justify="right").place(x=275, y=93)
    Label(wrapper1, image=kanan_img, font=30, bg="#f5f5f5").place(x=195, y=106)
    Label(wrapper1, text=f"{tanggalTiket()}\n                        ", fg="#444444", bg="#f5f5f5", font=("Microsoft JengHei", 10), justify="left").place(x=23, y=160)
    Label(wrapper1, text=f"{tanggalTiket()}\n                        ", fg="#444444", bg="#f5f5f5", font=("Microsoft JengHei", 10), justify="right").place(x=278, y=160)
    Label(wrapper1, text="Durasi {}\n                                  ".format(hitungDurasi()), fg="#444444", bg="#f5f5f5", font=("Arial", 9), justify="center").place(x=147, y=140)

    #################################################################
    Label(payment, text="Detail Harga", fg="#2F58CD", bg="#dfdfde", font=("Calibri", 14, "bold")).place(x=262, y=247)

    wrapper2 = CTkFrame(payment, width=400, height=160, fg_color="#f5f5f5", corner_radius=10)
    wrapper2.place(x=262, y=280)

    Label(wrapper2, text="{} / {}".format(namaKereta, inisialKelas()), fg="#000000", bg="#f5f5f5", font=("Calibri", 17)).place(x=16, y=9)
    Label(wrapper2, text=f"Penumpang x {jumlahPenumpang}", fg="#444444", bg="#f5f5f5", font=("Calibri", 11),justify="left").place(x=19, y=60)
    Label(wrapper2, text=f"{hitungHarga()}\n                        ", fg="#444444", bg="#f5f5f5", font=("Microsoft JengHei", 10), justify="right").place(x=278, y=60)
    Label(wrapper2, text="Total Harga", fg="#2F58CD", bg="#f5f5f5", font=("Calibri", 14, "bold")).place(x=20, y=110)
    Label(wrapper2, text=f"{hitungHarga()}\n                                     ", fg="#2F58CD", bg="#f5f5f5", font=("Calibri", 14, "bold"), justify="right").place(x=228, y=110)

    Frame(wrapper2, width=360, height=1, bg="#999999").place(x=20, y=95)

    ##################################################################

    CTkButton(payment, width=402, height=30, text="Bayar", font=("Vernada", 12),text_color="black", fg_color="#ff8400", hover_color="#ff6000", border_spacing=0, corner_radius=10, cursor="hand2", command=pembayaran).place(x=261, y=448)
    system("cls")

    payment.mainloop()

if __name__ == "__main__":
    loginAkun()